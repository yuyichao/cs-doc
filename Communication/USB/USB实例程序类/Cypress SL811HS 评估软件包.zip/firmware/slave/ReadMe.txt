This directory contains demo code that will enumerate the SL811S (in Slave Mode) as a simple 
HID Consumer Control device. You may download this firmware to the EZ-USB Dev Board, which
will configure the SL811HST Demo Board appropriately.
Currently only 3 consumer buttons were implemented; Audio mute, and volume up and down buttons. 
This demo code will perform the necessary USB standard and HID-Class requests for successful 
enmeration of the slave device.
To setup the ez811 demo board for this example: 
1) Insert the ez811 demo board onto the ezusb dev kit; 
2) On the ezusb dev kit, turn on bit 3 and 4 of S6; 
3) On the ez811 demo board, set JP1 to Slave Mode, set JP2 to Full Speed, set JP3 to 5V Dev Kit. 
4) (Optionally) Add 3 tact switches on Port C - Bit 0 to Bit 2 
   Mute, Vol Up,Vol Down respectively. All buttons are active low; 
5) You may omit step 4) if you are interested in viewing enumeration only. 
6) Now, insert the USB cable to connect the EZUSB board. 
   Use the EZ-USB Contro Panel to download the hex code. 
7) When that is done, you should see host LED off and Active LED off; 
8) Using another USB cable and USB port on your PC:
   connect J2 (USB series B connector) to the PC.
9) If successful, in the "Device Manager" you should see 2 new entries:
   1) HID-Compliant consumer control device.
   2) USB Human Interface Device.
10) Try the 3 buttons to control the Mute, Volume Up/Down of your sound card.

