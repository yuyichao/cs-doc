////////////////////////////////////////////////////////////////////////////////
// Cypress Semiconductor - Customer Design Center 
////////////////////////////////////////////////////////////////////////////////
// File:		host_811.c
// Purpose:	    8051 firmware to master SL811 Embedded Host. 
//              Contains SL811-related control firmware. 
//              Based on SL811HST code written by cxn.
// H/W Target:  SL811HST(Rev 1.5) + EZUSB DEV KIT
// IMPORTANT :  Turn ON SW4 of S6-DIP-SWITCH 
//              to enable upper 32K memory on EZUSB Dev Kit
//
// $Header: /USB/ez811/firmware/Emb_Host/host_811.c 8     5/14/02 8:30p Tpm $
// Copyright (c) 2002 Cypress Semiconductor. May not be reproduced without permission.
// See the license agreement for more details.
////////////////////////////////////////////////////////////////////////////////

#include "ezusb.h"
#include "ezregs.h"
#include "host_811.h"

////////////////////////////////////////////////////////////////////////////////
// Code and Xdata Memory Space
////////////////////////////////////////////////////////////////////////////////
//
// ** Upper 32K external memory **
// (PROGRAM'S CODE/XDATA MEMORY ALLOCATION)
// Program xdata Space	: 0x2000 ~ 0x23FF -> ALL XDATA (size:0x0400,1K)(ISO unused data mem)
// Program Code Space1	: 0x8000 ~ 0x9EFF -> ?FW, ?EZ811 (size:0x1F00,7K) (ext. code memory) 
// Program Code Space2	: 0xA000 ~ 0xDFFF -> ?SL811H (size:0x4000,16K)(ext. code memory) 
// (MONITOR'S CODE/XDATA MEMORY ALLOCATION) (SHOULD NEVER BE USED)
// Monitor xdata Space	: 0x9F00 ~ 0x9FFF (size:0x0100,256)(ext. code memory) 
// Monitor Code Space	: 0xE000 ~ 0xFFFF (size:0x2000,8K) (ext. code memory) 
//
// ** Lower 32K external memory **
// SL811H_ADDR address	: 0x4000
// SL811H_DATA address	: 0x4001
//
// ** Internal 8K EZUSB code/xdata memory **
// Both USBJmpTb.a51 and Dscr.a51 code are located to EZUSB internal 8K memory
//
// (See Project -> Options for Target 'Target 1' for detail settings)
//
//*****************************************************************************************
// SL811H Modules (major routines only): 
//*****************************************************************************************
// 1) usbXfer()		: handles usd data transfer, SETUP,IN, OUT
// 2) ep0Xfer()		: handles endpoint zero control pipe
// 3) DataRW()		: handles data endpoint transfer pipe
// 4) EnumUsbDev() 	: device enum(HID/HUB), excl. multi-interface
// 5) HubPortEnum()	: hub port device enum, incl. dynamic USB address
// 6) speed_detect(): SL811H slave device attach/speed detect
// 7) slave_detect(): Main loop control between SL811H & EZUSB & GUI
// 8) host_811.c	: Entire code size

//*****************************************************************************************
// SL811HST+EZUSB Hardware Resources :
//*****************************************************************************************
// SL811HST		<-->	AN2131QC	<-->	FUNCTIONS (looking from SL811H side)
// A0			<-->	A0			<-->	(I) Address entry for SL811H, '0'-addr, '1'-data
// D0 ~ D7		<-->	D0 ~ D7		<-->	(B) 8-bit Data Bus
// nCS			<-->	A15			<-->	(I) Enable lower 32K memory(where SL811H is mapped)
// nRD 			<-->	nRD (PC7)	<-->	(I) Read (active low)
// nWR			<-->	nWR (PC6)	<-->	(I) Write (active low)
// nRST			<-->	PB0			<-->	(I) SL811HST's reset (active low)
// MS_SEL		<-->	PB1			<-->	(I) SL811HST's master/slave select, '0'-host
// INTR			<-->	INT4 (PB4)	<-->	(O) SL811HST's interrupt (active high) not used
// ACTIVE_LED	<-->	PB6			<-->	Blink - waiting for enum, On - enumerated
//
// For Downstream Port LEDs on Hub (not present on Demo Board):
// DOWNSTREAM PORT1 LED			0x80	// PA bit 7
// DOWNSTREAM PORT2 LED			0x40	// PA bit 6
// DOWNSTREAM PORT3 LED			0x20	// PA bit 5
// DOWNSTREAM PORT4 LED			0x10	// PA bit 4
//
//*****************************************************************************************
// Monitor (Serial Port 1) Hardware Resources :
//*****************************************************************************************
// PB2 - (I) RxD1 (looking from EZUSB side)
// PB2 - (0) TxD1
// PC6 - (O) nWR
// PC7 - (O) nRD

//*****************************************************************************************
// xdata variables
//*****************************************************************************************
xdata BYTE SL811H_ADDR		_at_	0x4000;		// A0 = '0' to external memory
xdata BYTE SL811H_DATA  	_at_	0x4001;     // A0 = '1' (EZ-USB Dev Kit - SW4 ON)

xdata BYTE 			DBUF[256];		// at 0x2000 for general descriptors data
xdata BYTE 			STATUS[8];		// for status data buffer
xdata BYTE          REGBUFF[16];    // Buffer for Register Data
xdata BYTE 			HOSTCMD[8];		// EZUSB's OUT1 host command data
xdata BYTE 			pHOSTCMD[8];	// previous data transfer info, during data transfer
xdata BYTE 			HubChange[1];	// Hub port endpoint 1 data status
xdata BYTE 			DataBufLen;		// EZUSB's IN #3 data transfer buffer length
xdata BYTE 			pNumPort;		// Number of downstream ports on hub
xdata BYTE			remainder;		// Remaining byte in a USB transfer
xdata pUSBDEV  		uDev[MAX_DEV];	// Multiple USB devices attributes, Max 5 devices
xdata pHUBDEV		uHub;			// Struct for downstream device on HUB
xdata pDevDesc  	pDev;			// Device descriptor struct
xdata pCfgDesc 		pCfg;			// Configuration descriptor struct
xdata pIntfDesc 	pIfc;			// Interface descriptor struct
xdata pEPDesc 		pEnp;			// Endpoint descriptor struct
xdata pStrDesc 		pStr;			// String descriptor struct
xdata pHidDesc 		pHid;			// HID class descriptor struct
xdata pHubDesc 		pHub;			// HUD class descriptor struct
xdata pPortStatus	pStat;			// HID ports status

//*****************************************************************************************
// Boolean Logic Defines
//*****************************************************************************************
BOOL  	SLAVE_FOUND;				// Slave USB device found
BOOL  	SLAVE_ENUMERATED;			// slave USB device enumeration done
BOOL  	FULL_SPEED;					// Full-Speed = TRUE, Low-Speed = FALSE
BOOL	HUB_DEVICE;					// HUB device = TRUE
BOOL 	BULK_OUT_DONE;				// Set when EZUSB's OUT1 hostcmd xfer is done
BOOL 	DESC_XFER;					// Set when there is data for EZUSB's IN1 desc xfer
BOOL 	DATA_XFER;					// Set when there is data for EZUSB's IN3 data xfer
BOOL 	DATA_XFER_OUT;				// Set when there is data for EZUSB's OUT3 data xfer
BOOL 	CONFIG_DONE;				// Set when EZUSB completes its enumeration process.
BOOL 	TIMEOUT_ERR;				// timeout error during data endpoint transfer
BOOL	DATA_STOP;					// device unplugged during data transfer
BOOL	DATA_INPROCESS;				// set when we are in a data pipe transfer
BOOL	pLS_HUB;					// indicate previous command is a LS device on hub

BOOL	dsPoll;				        // poll downstream port conections

BOOL bData1;

//*****************************************************************************************
// Byte Read from SL811H
// a = register address
// return = data in register
//*****************************************************************************************
BYTE SL811Read(BYTE a)
{  
	SL811H_ADDR = a;			
	return (SL811H_DATA);
}

//*****************************************************************************************
// Byte Write to SL811H
// a = register address
// d = data to be written to this register address
//*****************************************************************************************
void SL811Write(BYTE a, BYTE d)
{  
	SL811H_ADDR = a;	
	SL811H_DATA = d;
}

//*****************************************************************************************
// Buffer Read from SL811H
// addr = buffer start address
// s    = return buffer address where data are to be save/read
// c	= buffer data length
//*****************************************************************************************
void SL811BufRead(BYTE addr, BYTE *s, BYTE c)
{	
	SL811H_ADDR = addr;	
   	while (c--) 
		*s++ = SL811H_DATA;
}

//*****************************************************************************************
// Buffer Write  to SL811H
// addr = buffer start address
// s    = buffer address where data are to be written
// c	= buffer data length
//*****************************************************************************************
void SL811BufWrite(BYTE addr, BYTE *s, BYTE c)
{	
	SL811H_ADDR = addr;	
   	while (c--) 
		SL811H_DATA = *s++;
}

//*****************************************************************************************
// Swap high and low byte 
//*****************************************************************************************
WORD WordSwap(WORD input)
{
	return(((input&0x00FF)<<8)|((input&0xFF00)>>8));
}

//*****************************************************************************************
// UsbReset during enumeration of device attached directly to SL811HS
//*****************************************************************************************
void USBReset()
{
	BYTE tmp;
    tmp =  SL811Read(CtrlReg);   
 	SL811Write(CtrlReg,tmp|0x08);
	EZUSB_Delay(25);			
    SL811Write(CtrlReg,tmp);    
}

//*****************************************************************************************
// usbXfer:
// successful transfer = return TRUE
// fail transfer = return FALSE
//*****************************************************************************************
int usbXfer(BYTE usbaddr, BYTE endpoint, BYTE pid, BYTE iso, WORD wPayload, WORD wLen, BYTE *buffer)
{  
	xdata BYTE 	cmd, result, timeout, intr;
	xdata BYTE	xferLen, bufLen, data0, data1, dataX, addr;
	
	//------------------------------------------------
	// Default setting for usb trasnfer
	//------------------------------------------------
	bufLen = dataX = timeout = 0;					//reset all
	data0 = EP0_Buf;								// DATA0 buffer address
	data1 = data0 + (BYTE)wPayload;					// DATA1 buffer address
	DATA_STOP =	TIMEOUT_ERR = FALSE;				// set default conditions

	//------------------------------------------------
	// Define data transfer payload
	//------------------------------------------------
	if (wLen >= wPayload)  							// select proper data payload
		xferLen = wPayload;							// limit to wPayload size 
	else											// else take < payload len
		xferLen = wLen;								//	

	//------------------------------------------------
	// For IN token
	//------------------------------------------------
	if (pid==PID_IN)								// for current IN tokens
	{												//
		if(FULL_SPEED)								//
			cmd = sDATA0_RD;						// FS/FS on Hub, sync to sof
		else										// LS, no sync to sof for IN
			cmd = DATA0_RD;							//
		//-------------------------------------------- response to OUT can propagate to SL811HS
		// handling LS device on HUB
		//--------------------------------------------
		if(HUB_DEVICE && usbaddr!=HUB_ADDR)			// Transfer on Hub, USB addr #0, #2..#5 only
		{
			if(uHub.bPortSpeed[usbaddr])			// If transfer of LS on Hub & previous is			
				cmd = psDATA0_RD;					// SETUP & current is IN, no sync to sof,
		}
	}
	//------------------------------------------------
	// For OUT token
	//------------------------------------------------
	else if(pid==PID_OUT)							// for OUT tokens
	{  	
		if(xferLen)									// only when there are	
			SL811BufWrite(data0,buffer,xferLen); 	// data to transfer on USB

		if(FULL_SPEED)								
			cmd = sDATA0_WR;						// FS/FS on Hub, sync to sof
		else										// LS, no sync to sof for OUT
			cmd = DATA0_WR;							
		//--------------------------------------------
		// handling LS device on HUB
		//--------------------------------------------
		if(HUB_DEVICE && usbaddr!=HUB_ADDR)			// Transfer on Hub, USB addr #0, #2..#5 only
		{
			if(uHub.bPortSpeed[usbaddr])			// If transfer of LS on Hub, previous
				cmd = psDATA0_WR;
		}
		// implement data toggle
		bData1 = uDev[usbaddr].bData1[endpoint];
        uDev[usbaddr].bData1[endpoint] = (uDev[usbaddr].bData1[endpoint] ? 0 : 1); // DataToggle
		if(bData1)
          cmd |= 0x40;                              // Set Data1 bit in command
	}
	//------------------------------------------------
	// For SETUP/OUT token
	//------------------------------------------------
	else											// for current SETUP/OUT tokens
	{  	
		if(xferLen)									// only when there are	
			SL811BufWrite(data0,buffer,xferLen); 	// data to transfer on USB

		if(FULL_SPEED)								
			cmd = sDATA0_WR;						// FS/FS on Hub, sync to sof
		else										// LS, no sync to sof for OUT
			cmd = DATA0_WR;							
		//--------------------------------------------
		// handling LS device on HUB
		//--------------------------------------------
		if(HUB_DEVICE && usbaddr!=HUB_ADDR)			// Transfer on Hub, USB addr #0, #2..#5 only
		{
			if(uHub.bPortSpeed[usbaddr])			// If transfer of LS on Hub, previous
				cmd = psDATA0_WR;
		}
	}

	//------------------------------------------------
	// Isochronous data transfer setting
	//------------------------------------------------
	if (iso) 
		cmd |= ISO_BIT;                     		// if iso setup ISO mode

	//------------------------------------------------
	// For EP0's IN/OUT token data, start with DATA1
	// Control Endpoint0's status stage.
	// For data endpoint, IN/OUT data, start ????
	//------------------------------------------------
	if (endpoint == 0 && pid != PID_SETUP) 			// for Ep0's IN/OUT token
		cmd |= 0x40; 								// always set DATA1

	//------------------------------------------------
	// Arming of USB data transfer for the first pkt
	//------------------------------------------------
	SL811Write(EP0Status,((endpoint&0x0F)|pid));	// PID + EP address
	SL811Write(EP0Counter,usbaddr);					// USB address
	SL811Write(EP0Address,data0);					// buffer address, start with "data0"
	SL811Write(EP0XferLen,xferLen);					// data transfer length
	SL811Write(IntStatus,INT_CLEAR); 				// clear interrupt status
	SL811Write(EP0Control,cmd);						// Enable ARM and USB transfer start here

	//------------------------------------------------
	// Main loop for completing a wLen data trasnfer
	//------------------------------------------------
	while(TRUE)
	{   
		//---------------Wait for done interrupt------------------
		while(TRUE)												// always ensure requested device is
		{														// inserted at all time, then you will
			intr = SL811Read(IntStatus);						// wait for interrupt to be done, and 
			if((intr & USB_RESET) || (intr & INSERT_REMOVE))	// proceed to parse result from slave 
			{													// device.
				DATA_STOP = TRUE;								// if device is removed, set DATA_STOP
				return FALSE;									// flag true, so that main loop will 
			}													// know this condition and exit gracefully
			if(intr & USB_A_DONE)								
				break;											// interrupt done !!!
		}

		SL811Write(IntStatus,INT_CLEAR); 						// clear interrupt status
		result 	  = SL811Read(EP0Status);						// read EP0status register
		remainder = SL811Read(EP0Counter);						// remainder value in last pkt xfer

		//-------------------------ACK----------------------------
		if (result & EP0_ACK)									// Transmission ACK
		{	

			// SETUP TOKEN
			if(pid == PID_SETUP)								// do nothing for SETUP/OUT token 
				break;											// exit while(1) immediately

			// OUT TOKEN				
			else if(pid == PID_OUT)
				break;

			// IN TOKEN
			else if(pid == PID_IN)
			{													// for IN token only
				wLen  -= (WORD)xferLen;							// update remainding wLen value
				cmd   ^= 0x40;    								// toggle DATA0/DATA1
				dataX++;										// point to next dataX

				//------------------------------------------------	
				// If host requested for more data than the slave 
				// have, and if the slave's data len is a multiple
				// of its endpoint payload size/last xferLen. Do 
				// not overwrite data in previous buffer.
				//------------------------------------------------	
				if(remainder==xferLen)							// empty data detected
					bufLen = 0;									// do not overwriten previous data
				else											// reset bufLen to zero
					bufLen = xferLen;							// update previous buffer length
				
				//------------------------------------------------	
				// Arm for next data transfer when requested data 
				// length have not reach zero, i.e. wLen!=0, and
				// last xferlen of data was completed, i.e.
				// remainder is equal to zero, not a short pkt
				//------------------------------------------------	
				if(!remainder && wLen)							// remainder==0 when last xferLen
				{												// was all completed or wLen!=0
					addr    = (dataX & 1) ? data1:data0; 		// select next address for data
					xferLen = (BYTE)(wLen>=wPayload) ? wPayload:wLen;	// get data length required
					if (FULL_SPEED)								// sync with SOF transfer
						cmd |= 0x20;							// always sync SOF when FS, regardless 
					SL811Write(EP0XferLen, xferLen); 			// select next xfer length
					SL811Write(EP0Address, addr);           	// data buffer addr 
					SL811Write(IntStatus,INT_CLEAR);			// is a LS is on Hub.
					SL811Write(EP0Control,cmd);					// Enable USB transfer and re-arm
				}				

				//------------------------------------------------
				// Copy last IN token data pkt from prev transfer
				// Check if there was data available during the
				// last data transfer
				//------------------------------------------------
				if(bufLen)										
				{	
					SL811BufRead(((dataX&1)?data0:data1), buffer, bufLen);
					buffer += bufLen;								
				}

				//------------------------------------------------
				// Terminate on short packets, i.e. remainder!=0
				// a short packet or empty data packet OR when 
				// requested data len have completed, i.e.wLen=0
				// For a LOWSPEED device, the 1st device descp,
				// wPayload is default to 64-byte, LS device will
				// only send back a max of 8-byte device descp,
				// and host detect this as a short packet, and 
				// terminate with OUT status stage
				//------------------------------------------------
				if(remainder || !wLen)
					break;
			}							
		}
		
		//-------------------------NAK----------------------------
		if (result & EP0_NAK)									// NAK Detected
		{														
			if(endpoint==0)										// on ep0 during enumeration of LS device
			{													// happen when slave is not fast enough,
				SL811Write(IntStatus,INT_CLEAR);				// clear interrupt status, need to
				SL811Write(EP0Control,cmd);						// re-arm and request for last cmd, IN token
                result = 0;                                     // respond to NAK status only
			}
			else												// normal data endpoint, exit now !!! , non-zero ep
				break;											// main loop control the interval polling
		}
		
		//-----------------------TIMEOUT--------------------------
		if (result & EP0_TIMEOUT)								// TIMEOUT Detected
		{														
			if(endpoint==0)										// happens when hub enumeration
			{
				if(++timeout >= TIMEOUT_RETRY)
				{	
				    timeout--;
					break;										// exit on the timeout detected	
				}
				SL811Write(IntStatus,INT_CLEAR);				// clear interrupt status, need to
				SL811Write(EP0Control,cmd);						// re-arm and request for last cmd again
			}
			else												
			{													// all other data endpoint, data transfer 
				TIMEOUT_ERR = TRUE;								// failed, set flag to terminate transfer
				break;											// happens when data transfer on a device
			}													// through the hub
		}

		//-----------------------STALL----------------------------
		if (result & EP0_STALL)  								// STALL detected
			return TRUE;										// for unsupported request.
																		
		//----------------------OVEFLOW---------------------------
		if (result & EP0_OVERFLOW)  							// OVERFLOW detected
			break;
		//-----------------------ERROR----------------------------
		if (result & EP0_ERROR)  								// ERROR detected
			break;
	}	// end of While(1)
   
	if (result & EP0_ACK) 	// on ACK transmission
		return TRUE;		// return OK

	return FALSE;			// fail transmission
}

//*****************************************************************************************
// Control Endpoint 0's USB Data Xfer
// ep0Xfer, endpoint 0 data transfer
//*****************************************************************************************
int ep0Xfer(BYTE usbaddr, WORD payload, pSetupPKG setup, BYTE *pData)
{
	xdata BYTE	pid  = PID_IN;
	xdata WORD	wLen = WordSwap(setup->wLength);		// swap back for correct length
	xdata BYTE	ep0 = 0;								// always endpoint zero

	//----------------------------------------------------
	// SETUP token with 8-byte request on endpoint 0
	//----------------------------------------------------
	if (!usbXfer(usbaddr, ep0, PID_SETUP, 0, payload, 8, (BYTE*)setup)) 
   		return FALSE;

	//----------------------------------------------------
	// IN or OUT data stage on endpoint 0	
	//----------------------------------------------------
   	if (wLen)											// if there are data for transfer
	{
		if (setup->bmRequest & 0x80)					// host-to-device : IN token
		{
			pid  = PID_OUT;	
			if(!usbXfer(usbaddr, ep0, PID_IN, 0, payload, wLen, pData))
				return FALSE;
			payload = 0;
		}
		else											// device-to-host : OUT token
   		{							
			if(!usbXfer(usbaddr, ep0, PID_OUT, 0, payload, wLen, pData))
				return FALSE;
		}
	}

	//----------------------------------------------------
	// Status stage IN or OUT zero-length data packet
	//----------------------------------------------------
	if(!usbXfer(usbaddr, ep0, pid, 0, payload, 0, NULL))
		return FALSE;

	return TRUE;											
}

//*****************************************************************************************
// Control endpoint
//*****************************************************************************************
int VendorCmd(BYTE usbaddr,BYTE bReq,BYTE bCmd,WORD wValue,WORD wIndex,WORD wLen,BYTE *pData)
{ 
    xdata SetupPKG setup;

    setup.bmRequest  = bReq;
    setup.bRequest   = bCmd;
    setup.wValue     = wValue;
    setup.wIndex     = wIndex;
    setup.wLength    = WordSwap(wLen);

   	return ep0Xfer(usbaddr, uDev[usbaddr].wPayLoad[0], &setup, pData);
}

//*****************************************************************************************
// Set Device Address : 
//*****************************************************************************************
int SetAddress(WORD addr)
{
	return VendorCmd(0,0,SET_ADDRESS, WordSwap(addr), 0, 0, NULL);
}

//*****************************************************************************************
// Set Device Configuration : 
//*****************************************************************************************
int Set_Configuration(BYTE usbaddr, WORD wVal)
{
	return VendorCmd(usbaddr, 0, SET_CONFIG, WordSwap(wVal), 0, 0, NULL);
}

//*****************************************************************************************
// Get Device Descriptor : Device, Configuration, String
//*****************************************************************************************
int GetDesc(BYTE usbaddr, WORD wValue, 	WORD wIndex, WORD wLen, BYTE *desc)
{ 
	return VendorCmd(usbaddr, 0x80, GET_DESCRIPTOR, wValue, wIndex, wLen, desc);
}

//*****************************************************************************************
// HID Get_Desc :
//*****************************************************************************************
int GetHid_Desc(BYTE usbaddr, WORD wValue, WORD wLen, BYTE *desc)
{ 
	return VendorCmd(usbaddr, 0x81, GET_DESCRIPTOR, wValue, 0, wLen, desc);
}

//*****************************************************************************************
// GetHUBDesc :
//*****************************************************************************************
int GetHubDesc(BYTE usbaddr, WORD wValue, WORD wLen, BYTE *desc)
{ 
	return VendorCmd(usbaddr, 0xA0, GET_DESCRIPTOR, wValue, 0, wLen, desc);
}

//*****************************************************************************************
// Get Status : (HUB)
//*****************************************************************************************
int GetStatus(BYTE usbaddr, BYTE *desc)
{ 
	return VendorCmd(usbaddr, 0x80, GET_STATUS, 0, 0, 2, desc);		 
}

//*****************************************************************************************
// PortFeature : (SET_FEATURE, CLEAR_FEATURE)
//*****************************************************************************************
int PortFeature(BYTE usbaddr, BYTE bReq, WORD wValue, BYTE cPort)
{ 
	return VendorCmd(usbaddr, 0x23, bReq, WordSwap(wValue), WordSwap((WORD)cPort), 0, NULL);		  
}

//*****************************************************************************************
// GetPortStatus :
//*****************************************************************************************
int GetPortStatus(BYTE usbaddr, BYTE cPort, BYTE *desc)
{ 
	return VendorCmd(usbaddr, 0xA3, GET_STATUS, 0, WordSwap((WORD)cPort), 0x04, desc);
}

//*****************************************************************************************
// GetDevInfo :
//*****************************************************************************************
WORD GetDevInfo(BYTE *DevInfo)
{ 
  BYTE EpAddr;
  int i;
  BYTE DescBufLen = 0;

		for(EpAddr = 1; (EpAddr < MAX_DEV); EpAddr++)
		{
			if(uHub.bPortPresent[EpAddr])
			{
					 	DevInfo[DescBufLen++] = EpAddr;							// USB Address
 						DevInfo[DescBufLen++]	= uHub.bPortNumber[EpAddr];			// Port Number
						DevInfo[DescBufLen++] = uHub.bPortSpeed[EpAddr];			// Device Speed (from enum)
						DevInfo[DescBufLen++] = uDev[EpAddr].bClass;				// Class Type (from enum)
						(WORD)DevInfo[DescBufLen++] = uDev[EpAddr].wVID;			// VID
						DescBufLen++;
						(WORD)DevInfo[DescBufLen++] = uDev[EpAddr].wPID;			// PID
						DescBufLen++;
						DevInfo[DescBufLen++] = (BYTE)uDev[EpAddr].wPayLoad[0];	// Ep0 MaxPktSize (max 64 bytes)
						DevInfo[DescBufLen++] = uDev[EpAddr].bNumOfEPs;			// Number of data endpoints
						for(i=0;i<uDev[EpAddr].bNumOfEPs;i++)		// save all data endpoints info
						{												
							DevInfo[DescBufLen++] 	= uDev[EpAddr].bEPAddr[i+1];	// ep address/direction
							DevInfo[DescBufLen++] 	= uDev[EpAddr].bAttr[i+1];		// transfer type
							(WORD)DevInfo[DescBufLen++] = uDev[EpAddr].wPayLoad[i+1];	// max data payload
							DescBufLen++;                                       // 2 byte payload
							DevInfo[DescBufLen++] 	= uDev[EpAddr].bInterval[i+1];	// polling interval
						}	
			}
		}
		return(DescBufLen);
}

//*****************************************************************************************
// USB Data Endpoint Read/Write
// wLen is in low byte first format
//*****************************************************************************************
int DataRW(BYTE usbaddr, BYTE epaddr, WORD wPayload, WORD wLen, BYTE *pData)
{
	xdata BYTE pid = PID_OUT;

	if(epaddr & 0x80)	// get direction of transfer
		pid = PID_IN;				

	if(usbXfer(usbaddr,epaddr&0x0F,pid,0,wPayload,wLen,pData))
		return TRUE;

	return FALSE;
}

//*****************************************************************************************
// USB Device Enumeration Process
// Support 1 confguration and interface #0 and alternate setting #0 only
// Support up to 1 control endpoint + 4 data endpoint only
//*****************************************************************************************
int EnumUsbDev(BYTE usbaddr)
{  
	int i;											// always reset USB transfer address 
	xdata BYTE uAddr = 0;							// for enumeration to Address #0
	xdata BYTE epLen;
	xdata WORD strLang;

	//------------------------------------------------
	// Reset only Slave device attached directly
	//------------------------------------------------
	uDev[0].wPayLoad[0] = 64;						// default 64-byte payload of Endpoint 0, address #0
	if(usbaddr == 1)								// bus reset for the device attached to SL811HS only
		USBReset();									// that will always have the USB address = 0x01 (for a hub)
    EZUSB_Delay(25);

	//------------------------------------------------
	// Get USB Device Descriptors on EP0 & Addr 0
	// with default 64-byte payload
	//------------------------------------------------
	pDev =(pDevDesc)DBUF;							// ask for 64 bytes on Addr #0
	if (!GetDesc(uAddr,DEVICE,0,18,DBUF))			// and determine the wPayload size
		return FALSE;								// get correct wPayload of Endpoint 0
	uDev[usbaddr].wPayLoad[0]=pDev->bMaxPacketSize0;// on current non-zero USB address

	//------------------------------------------------
	// Set Slave USB Device Address
	//------------------------------------------------
	if (!SetAddress(usbaddr)) 						// set to specific USB address
		return FALSE;								//
	uAddr = usbaddr;								// transfer using this new address

	//------------------------------------------------
	// Get USB Device Descriptors on EP0 & Addr X
	//------------------------------------------------
	if (!GetDesc(uAddr,DEVICE,0,(pDev->bLength),DBUF)) 	
		return FALSE;								// For this current device:
	uDev[usbaddr].wVID 	 = pDev->idVendor;			// save VID
	uDev[usbaddr].wPID 	 = pDev->idProduct;			// save PID
	uDev[usbaddr].iMfg 	 = pDev->iManufacturer;		// save Mfg Index
	uDev[usbaddr].iPdt 	 = pDev->iProduct;			// save Product Index

	//------------------------------------------------
	// Get String Descriptors
	//------------------------------------------------
	pStr = (pStrDesc)DBUF;	
	if (!GetDesc(uAddr,STRING,0,4,DBUF)) 			// Get string language
		return FALSE;								
	strLang = pStr->wLang;							// get iManufacturer String length
	if (!GetDesc(uAddr,(WORD)(uDev[usbaddr].iMfg<<8)|STRING,strLang,4,DBUF)) 		
		return FALSE;								// get iManufacturer String descriptors
	if (!GetDesc(uAddr,(WORD)(uDev[usbaddr].iMfg<<8)|STRING,strLang,pStr->bLength,DBUF)) 		
		return FALSE;			

	//------------------------------------------------
	// Get Slave USB Configuration Descriptors
	//------------------------------------------------
	pCfg = (pCfgDesc)DBUF;									
	if (!GetDesc(uAddr,CONFIGURATION,0,8,DBUF)) 		
		return FALSE;										
	if (!GetDesc(uAddr,CONFIGURATION,0,WordSwap(pCfg->wLength),DBUF)) 	
		return FALSE;		

	pIfc = (pIntfDesc)(DBUF + 9);					// point to Interface Descp
	uDev[usbaddr].bClass 	= pIfc->iClass;			// update to class type
	uDev[usbaddr].bNumOfEPs = (pIfc->bEndPoints <= MAX_EP) ? pIfc->bEndPoints : MAX_EP;

	//------------------------------------------------
	// Set configuration (except for HUB device)
	//------------------------------------------------
	if (uDev[usbaddr].bClass!=HUBCLASS)				// enumerating a FS/LS non-hub device
		if (!Set_Configuration(uAddr,DEVICE))		// connected directly to SL811HS
				return FALSE;

	//------------------------------------------------
	// For each slave endpoints, get its attributes
	// Excluding endpoint0, only data endpoints
	//------------------------------------------------
	epLen = 0;
	for (i=1; i<=uDev[usbaddr].bNumOfEPs; i++)				// For each data endpoint
	{
		pEnp = (pEPDesc)(DBUF + 9 + 9 + epLen);	   			// point to Endpoint Descp(non-HID)
		if(pIfc->iClass == HIDCLASS)	
			pEnp = (pEPDesc)(DBUF + 9 + 9 + 9 + epLen);		// update pointer to Endpoint(HID)
		uDev[usbaddr].bEPAddr[i]  	= pEnp->bEPAdd;			// Ep address and direction
		uDev[usbaddr].bAttr[i]		= pEnp->bAttr;			// Attribute of Endpoint
		uDev[usbaddr].wPayLoad[i] 	= pEnp->wPayLoad;		// Payload of Endpoint
		uDev[usbaddr].bInterval[i] 	= pEnp->bInterval;		// Polling interval
	    uDev[usbaddr].bData1[i] = 0;			            // init data toggle
		epLen += 7;
	}

	//------------------------------------------------
	// Get Hid Report Descriptors
	//------------------------------------------------
	if(pIfc->iClass == HIDCLASS)
	{	
		pHid = (pHidDesc)(DBUF + 9 + 9);	   				// point to HID-CLASS descp
		if (!GetHid_Desc(uAddr,HID_REPORT,pHid->wItemLength,DBUF))
			return FALSE;
	}

	//------------------------------------------------
	// Get HUB Class Specific Descriptor (per port switching)
	//------------------------------------------------
	if(uDev[usbaddr].bClass==HUBCLASS)
    {														// enumerating a HUB device		
   		pHub =(pHubDesc)DBUF;								// Ask for 71 bytes ???
	    if (!GetHubDesc(uAddr,0x00,0x47,DBUF))
			return FALSE;									// Get Hub Desriptor
		if (!GetStatus(uAddr,STATUS)) 
			return FALSE;     								// Get Status
		if (!Set_Configuration(uAddr,DEVICE))
			return FALSE;  									// Set configuration

		pNumPort = pHub->bNbrPort;							// save no. of ports available
		for(i=1; i<=pNumPort; i++)							// ClearPortFeature: C_PORT_CONNECTION off
		    if(!PortFeature(uAddr,CLEAR_FEATURE, C_PORT_CONNECTION,i))	
				return FALSE;

		for(i=1; i<=pNumPort; i++)							// SetPortFeature: PORT_POWER on
		{
		    if(!PortFeature(uAddr,SET_FEATURE, PORT_POWER, i)) 	
				return FALSE;								
		}

		for(i=1; i<=pHub->bNbrPort; i++)					// GetPortStatus(wHubStatus,wHubChange)
		   if( !GetPortStatus(uAddr,i,STATUS) ) 			//
				return FALSE;								//

		for(i=2;i<=pNumPort+1;i++)							// clear port present status
		{													// address #2..#5 only
			uHub.bPortPresent[i] = 0;						// clear status
			uHub.bPortNumber[i] = 0;						//
		}
		HUB_DEVICE = TRUE;									// Set Hub flag, as long as a hub is attached 
	}														// directly to the HUB_DEVICE will be set

	return TRUE;
}

//*****************************************************************************************
// Full-speed and low-speed detect - Device atttached directly to SL811HS
//*****************************************************************************************
int speed_detect() 
{
	pNumPort	= 0;					// zero no. of downstream ports
	SLAVE_FOUND	= FALSE;				// Clear USB device found flag
	FULL_SPEED  = TRUE;					// Assume full speed device
	HUB_DEVICE  = FALSE;				// not HUB device
	DATA_STOP	= FALSE;				//
 
	SL811Write(cSOFcnt,0xAE);      		// Set SOF high counter, no change D+/D-, host mode
	SL811Write(CtrlReg,0x08);      		// Reset USB engine, full-speed setup, suspend disable
	EZUSB_Delay(10);					// Delay for HW stablize
	SL811Write(CtrlReg,0x00);      		// Set to normal operation
	SL811Write(IntEna,0x61);      		// USB-A, Insert/Remove, USB_Resume.
	SL811Write(IntStatus,INT_CLEAR);	// Clear Interrupt enable status
	EZUSB_Delay(10);					// Delay for HW stablize

	if(SL811Read(IntStatus)&USB_RESET)
	{									// test for USB reset
		SL811Write(IntStatus,INT_CLEAR);// Clear Interrupt enable status
		EZUSB_Delay(30);				// Blink LED - waiting for slave USB plug-in
		OUTB ^= ACTIVE_BLINK;			// Blink Active LED
		OUTA |= PORTX_LED;				// clear debug LEDs
		return 0;						// exit speed_detect()
	}

	if((SL811Read(IntStatus)&USB_DPLUS)==0)	// Checking full or low speed	
	{									// ** Low Speed is detected ** //
		SL811Write(cSOFcnt,0xEE);   	// Set up host and low speed direct and SOF cnt
		SL811Write(cDATASet,0xE0); 		// SOF Counter Low = 0xE0; 1ms interval
		SL811Write(CtrlReg,0x21);  		// Setup 6MHz and EOP enable         
		uHub.bPortSpeed[1] = 1;			// low speed for Device #1
		FULL_SPEED = FALSE;				// low speed device flag
	}
	else	
	{									// ** Full Speed is detected ** //
		SL811Write(cSOFcnt,0xAE);   	// Set up host & full speed direct and SOF cnt
		SL811Write(cDATASet,0xE0);  	// SOF Counter Low = 0xE0; 1ms interval
		SL811Write(CtrlReg,0x05);   	// Setup 48MHz and SOF enable
		uHub.bPortSpeed[1] = 0;			// full speed for Device #1
	}

	OUTB |= ACTIVE_BLINK;				// clear Active LED
	SLAVE_FOUND = TRUE;					// Set USB device found flag
	SLAVE_ENUMERATED = FALSE;			// no slave device enumeration

	SL811Write(EP0Status,0x50);   		// Setup SOF Token, EP0
	SL811Write(EP0Counter,0x00);		// reset to zero count
	SL811Write(EP0Control,0x01);   		// start generate SOF or EOP

	EZUSB_Delay(25);					// Hub required approx. 24.1mS
	SL811Write(IntStatus,INT_CLEAR);	// Clear Interrupt status
	return 0;    						// exit speed_detect();
}

//*****************************************************************************************
// Detect USB Device
//*****************************************************************************************
int slave_detect(void)
{
	int retDataRW = FALSE;
	
	//-------------------------------------------------------------------------
	// Wait for EZUSB enumeration
	//-------------------------------------------------------------------------
	if(!CONFIG_DONE)						// start SL811H after EZ-USB is configured
		return 0;

	//-------------------------------------------------------------------------
	// Wait for SL811HS enumeration
	//-------------------------------------------------------------------------
	if(!SLAVE_ENUMERATED)					// only if slave is not configured
	{
		speed_detect();						// wait for an USB device to be inserted to 
		if(SLAVE_FOUND)						// the SL811HST host
		{
	  		if(EnumUsbDev(1))				// enumerate USB device, assign USB address = #1
			{
			   	SLAVE_ENUMERATED = TRUE;	// Set slave USB device enumerated flag
				uHub.bPortPresent[1] = 1;	// set device addr #1 present
				Set_ezDEV(1);				// inform master of new attach/detach
			}	
		}
	}

	//-------------------------------------------------------------------------
	// SL811HS enumerated, proceed accordingly
	//-------------------------------------------------------------------------
	else									
	{													
		OUTB &= ~ACTIVE_BLINK;				// Turn on Active LED, indicate successful slave enum
		if(Slave_Detach())					// test for slave device detach ???
			return 0;						// exit now.
		//----------------------------------------------
		// HUB DEVICE Polling (Addr #1, EndPt #1)		
		//----------------------------------------------
		// Polling of Hub deivce Endpoint #1 for any Port Attachement
		// for onboard HUB device, after enumeration, start to
		// transfer IN token to check for ports attachment
		// wLen = wPayload = 1 byte, always use USB address #1
		// if return is TRUE, a data pkt was ACK, data in HubChange
		// else is a NAK, no data was received 
		if(HUB_DEVICE && dsPoll)									
		{												
			retDataRW = DataRW(HUB_ADDR,uDev[1].bEPAddr[1],uDev[1].wPayLoad[1],1,HubChange);
			if(retDataRW) 
			{											
				HubPortEnum();							
				Set_ezDEV(1);                           // inform master of new attach/detach
			}											
			EZUSB_Delay(10);							// maintain a polling interval 
		}												
	} // end of else

	return 0;
}

//*****************************************************************************************
// Slave_Detach
//*****************************************************************************************
int Slave_Detach(void)
{
	if( (SL811Read(IntStatus)&INSERT_REMOVE) || (SL811Read(IntStatus)&USB_RESET) )
	{												// Test USB detached?
		SLAVE_ENUMERATED = FALSE;					// return to un-enumeration
		uHub.bPortPresent[1] = 0;					// Device #1 not present

		Set_ezDEV(1);								// inform master of slave detach
		SL811Write(IntStatus,INT_CLEAR); 			// clear interrupt status
		return TRUE;								// exit now !!!
	}

	return FALSE;
}

//*****************************************************************************************
// Indicate to EZUSB's endpoint #2 IN of a new device attach/detach
//*****************************************************************************************
void Set_ezDEV(BYTE chg)
{
	if( (dsPoll) && (!(IN2CS & bmEPBUSY)) )
	{
		IN2BUF[0] = chg;	// Arm endpoint #2, inform EZUSB host of attach/detatch
		IN2BC = 1;
	}
}

//*****************************************************************************************
// SL811H variables initialization
//*****************************************************************************************
void sl811h_init(void)
{	
	int i;

	for(i=0;i<MAX_DEV;i++)
	{
		uHub.bPortPresent[i] = 0;
		uHub.bPortNumber[i] = 0;
	}

	SL811H_DATA = 0x00;
	SL811H_ADDR = 0x00;
	pNumPort	= 0x00;			

	FULL_SPEED = TRUE;	
	HUB_DEVICE = FALSE;
	SLAVE_FOUND = FALSE;
	SLAVE_ENUMERATED = FALSE;
	BULK_OUT_DONE = FALSE;
	DESC_XFER = FALSE;
	DATA_XFER = FALSE;
	DATA_XFER_OUT = FALSE;
	DATA_INPROCESS = FALSE;
	pLS_HUB = FALSE;
	IN2BUF[0] = 0;

    dsPoll = 1;				    // poll downstream port conections

	//----------------------------
	// SL811H + EZUSB I/Os setup
	//----------------------------
	PORTBCFG &= 0xAC;			// Select i/o function for PB6, PB4, PB1, PB0
	OEB      |= 0x43;			// Set  PB6(Output), PB4(Input), PB1(Output), PB0(Output) 
	OUTB     |= 0x43;			// Default output high

	PORTACFG &= 0x0F;			// Select i/o function for PA7~PA4
	OEA      |= 0xF0;			// Set PA7~PA4(Output)
	OUTA     |= 0xF0;			// Default output high

	//----------------------------
	// Debug Monitor I/Os setup
	//----------------------------
	PORTBCFG |= 0x0C;			// Select alternate function RxD1(PB2) & RxD1(PB3)
	PORTCCFG |= 0xC0;			// Select alternate function nWR(PC6) & nRD(PC7)
								// Also needed for SL811H
	//----------------------------
	// SL811HST hardware reset
	//----------------------------
	OUTB &= ~nRESET;			// reset SL811HST
	EZUSB_Delay(5);				// for 5ms
	OUTB |= nRESET;				// clear reset
	OUTB &= ~nHOST_SLAVE_MODE;	// set to Host mode
}
