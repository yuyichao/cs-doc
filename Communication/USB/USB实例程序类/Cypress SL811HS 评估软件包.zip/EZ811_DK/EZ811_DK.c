////////////////////////////////////////////////////////////////////////////////
//	File:		EZ811_CP.c
//
// $Header: /USB/ez811/EZ811_DK/EZ811_DK.c 20    5/14/02 2:49p Tpm $
// Copyright (c) 2002 Cypress Semiconductor. May not be reproduced without permission.
// See the license agreement for more details.
// Based on code written by cxn.
////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include <malloc.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <process.h>
#include "resource.h"
#include <time.h>
#include <winioctl.h>
#include "ezusbsys.h"
#include "EZ811_DK.h"

HINSTANCE hGInstance = NULL;
#define DATA_BLOCK_SIZE		256
UCHAR	single_data = 0;	
char	*build_time = __TIME__;
char	*build_date = __DATE__;
ULONG	UsbAddr;
ULONG	EndPointAddr;
ULONG	DataSize;
BYTE	out1Buffer[DATA_BLOCK_SIZE];
BYTE	in1Buffer[DATA_BLOCK_SIZE];
int		in1Bytes = 0;
BYTE	in3Buffer[DATA_BLOCK_SIZE];
int		in3Bytes = 0;
BYTE	out3Buffer[DATA_BLOCK_SIZE];
int		out3Bytes = 0;
int     nOpsPending = 0;

BYTE	refData = 0;

BYTE	VenBuff[64];
BYTE	HostCommand[6];
// HostCommand[0] = type of command
// HostCommand[1] = USB Address
// HostCommand[2] = Endpoint Address/String Index
// HostCommand[3] = USB xfer type
// HostCommand[4] = xfer data length
// HostCommand[5] = loop enable

#define MAX_FILE_SIZE (1024*64)
unsigned char FileXferBuff[MAX_FILE_SIZE];
int fileXferBytes;

BOOL	HUB = FALSE;
BOOL	bRefreshThread = FALSE;
BOOL	bDataXferThread = FALSE;
DWORD   DataLineCount = 0;
BYTE    OutXferCount = 0;
BYTE    Pipe2InPended = 0;
UCHAR   InterfaceInfo[1024];
PUSBD_INTERFACE_INFORMATION pInterface;

#define ISOCHRONOUS			0x01
#define BULK				0x02
#define INTERRUPT			0x03

#define XFERSTOP0			0xDE	// code to indicate stop button pressed
#define XFERSTOP1			0xAF	// "OxDEAF"
#define NONEXIST0			0xDE	// code to indicate device does not exist for data start/stop
#define NONEXIST1			0xAD	// "OxDEAD"
#define NOT_APPL			0xFF	// indicate not applicable, in string & class descp

#define SL_RESET			0xD0
#define SL_DEVICE_DESCP		0xD1
#define SL_CONFIG_DESCP		0xD2
#define SL_CLASS_DESCP		0xD3
#define SL_STRING_DESCP		0xD4
#define SL_REFRESH			0xD5
#define SL_DATA_XFER_START	0xD6
#define SL_DATA_XFER_STOP	0xD7
#define SL_TOGGLE_DS_REFRESH 0xD8
#define SL_SHOW_REGS        0xD9

#define	ezCMD				HostCommand[0]
#define	ezADDR				HostCommand[1]
#define	ezENP				HostCommand[2]
#define	ezIDX				HostCommand[2]
#define	ezTYPE				HostCommand[3]
#define	ezLEN				HostCommand[4]
#define	ezREPEAT			HostCommand[5]

#define IS_IN_EP(EpIdx) (EpIdx & 0x80)

BOOL CALLBACK bMainDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
BOOL GetUsbAddress(HWND hDlg);
BOOL GetEndpointNum(HWND hDlg);
BOOL GetDataSize(HWND hDlg);
void AbortRefresh(HWND hDlg, HANDLE hDevice);
void FillBuffer(PUCHAR buffer, PUCHAR pattern, ULONG length);
void DumpStatusBox(PVOID pvBuffer, ULONG length, HWND hOutputBox);
void DumpString(PVOID pvBuffer, ULONG length, HWND hOutputBox);
void DispDevData(PVOID pvBuffer, ULONG length, HWND hOutputBox);
void Get_EZUSB_Device_Info(HANDLE hDevice, HWND hDlg);
void RefreshThread(LPVOID lpParameter);
void inDataXferThread(LPVOID lpParameter);
void msDelay(ULONG time);
char pcDriverName[MAX_DRIVER_NAME] = "Ezusb-0";
void OnFileTrans(HWND hDlg, char* pFile);
void OnOutputSave(HWND hDlg, HWND hDataBox, char* pFile);
void Vend_CmdXfer(LPVOID lpParameter);

char PIPE_TYPE_STRINGS[4][4] = { "CTL", "ISO", "BLK", "INT" };

char PIPE_DIRECTION[2][4] = { "OUT", "IN " };

void DispDataBox(PVOID pvBuffer, ULONG length, HWND hOutputBox1);
void EzSendMessage(HWND hLb, int OpType, int OtherOp, LPARAM pStr);

#define ABOUT_BOX_STR_0 "  EZ-811 Dev Kit Version 4.2"
#define ABOUT_BOX_STR_1 "  Cypress Semiconductor"

typedef struct CThreadInfo
{ // ThreadInfo class
    VENDOR_OR_CLASS_REQUEST_CONTROL	VenReq;
	HWND hOutputBox;
	HWND hStatusBox;
	HWND hInfoBox;
	HWND hDlg;
	char* strpcDriverName;
	WORD length;
	int pipeNum;
	DWORD request;
	DWORD value;
	DWORD index;
	int direction;
    BYTE VenBuff[VEN_BUFF_SIZE];
	int m_hOpPended;
	BOOL fileXfer;
} CThreadInfo;

CThreadInfo* pTh = NULL;


//**********************************************************************************
// WinMain
//**********************************************************************************
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
   hGInstance=hInstance;
   
   if(DialogBox(hInstance,"MAIN_DIALOG",NULL,(DLGPROC)bMainDlgProc)==-1)
      MessageBox(NULL,"Unable to create root dialog!","DialogBox failure",MB_ICONSTOP);

	return 0;
}


//**********************************************************************************
// Vendor Command Transfer
//**********************************************************************************
void Vend_CmdXfer(LPVOID lpParameter)
{
  HANDLE	hDevice = NULL;
  BOOLEAN	bResult = TRUE;
  BOOLEAN	bRepeatXfer;
  int		nBytes = 0;	
  int i;
  CThreadInfo* pTh = (CThreadInfo*)lpParameter;
  int sentBytes = 0;
  int sendBytes;
						
  pTh->VenReq.requestType=2; // vendor specific request type (2)
  pTh->VenReq.recepient=0; // recepient is device (0)

  bRepeatXfer = TRUE;
  while(bRepeatXfer && bResult) // do transfer once, then repeat if Repeat is selected
  {
	if(!bOpenDriver (&hDevice, pcDriverName))
	{
		EzSendMessage (pTh->hOutputBox, LB_ADDSTRING, 0, (LPARAM)"EZ-USB Transfer Failed - EZ-USB not present");
		bResult = FALSE; 
	}
	if( (pTh->VenReq.request == SL_DATA_XFER_START) && (!IS_IN_EP(pTh->VenReq.index)) && (pTh->fileXfer))
	{
		sendBytes = (fileXferBytes < MAX_EP0_PAYLOAD) ? fileXferBytes : MAX_EP0_PAYLOAD;
		memcpy(pTh->VenBuff, FileXferBuff+sentBytes, sendBytes);
		pTh->length = sendBytes;
	}
	if( (pTh->VenReq.request == SL_DATA_XFER_START) && (!IS_IN_EP(pTh->VenReq.index)) && (!pTh->fileXfer))
	{
		OutXferCount++;
		for(i=0; i<pTh->length; i++)
		  pTh->VenBuff[i] = OutXferCount;
	}

	//if (hDevice != NULL) 
	if((!nOpsPending) && (hDevice != NULL))
	{
	  nOpsPending++;
	  bResult = DeviceIoControl (hDevice,
								IOCTL_EZUSB_VENDOR_OR_CLASS_REQUEST,
								&(pTh->VenReq),
								sizeof(VENDOR_OR_CLASS_REQUEST_CONTROL),
								pTh->VenBuff,
								pTh->length,
								(unsigned long *)&nBytes,
								NULL);
	  nOpsPending--;
	}
	CloseHandle(hDevice);


	if(bResult)
	{
	  if(pTh->VenReq.request == SL_DATA_XFER_START)
		DispDataBox(pTh->VenBuff,nBytes,pTh->hOutputBox);
	  else if((pTh->VenReq.request == SL_DEVICE_DESCP)
		   || (pTh->VenReq.request == SL_CONFIG_DESCP))
	  {
		DumpStatusBox(pTh->VenBuff,nBytes,pTh->hStatusBox);
	  }
	  else if(pTh->VenReq.request == SL_CLASS_DESCP)
	  {
		if(nBytes)
		  DumpStatusBox(pTh->VenBuff,nBytes,pTh->hStatusBox);
		else
		  EzSendMessage (pTh->hStatusBox, LB_ADDSTRING, 0, (LPARAM)"Non-HID/HUB class USB device");
	  }
	  else if(pTh->VenReq.request == SL_STRING_DESCP)
	  {
		if(nBytes)
		  DumpString(pTh->VenBuff,nBytes,pTh->hStatusBox);
		else
		  EzSendMessage (pTh->hStatusBox, LB_ADDSTRING, 0, (LPARAM)"No String Descriptor");
	  }
	  else if(pTh->VenReq.request == SL_REFRESH)
	  {
		if(nBytes)
		{
	  	  DispDevData(pTh->VenBuff,nBytes,pTh->hInfoBox);
		}
	  }
	  else if(pTh->VenReq.request == SL_SHOW_REGS)
	  {
		DumpStatusBox(pTh->VenBuff,nBytes,pTh->hStatusBox);
	  }

	}
	else
	{
	  CheckDlgButton(pTh->hDlg,IDC_REPEAT,BST_UNCHECKED);
	  EzSendMessage (pTh->hOutputBox, LB_ADDSTRING, 0, (LPARAM)"Vendor Request to EZ-USB Failed");
	}

	bRepeatXfer = (IsDlgButtonChecked(pTh->hDlg,IDC_REPEAT)==BST_CHECKED);

	if( (pTh->VenReq.request == SL_DATA_XFER_START) && (!IS_IN_EP(pTh->VenReq.index)) && (pTh->fileXfer))
	{
		sentBytes += sendBytes;
		if(sentBytes < fileXferBytes)
			bRepeatXfer = 1;
		else
			bRepeatXfer = 0;
	}

  }
  free(pTh); // this makes the thread evaporate
}

//**********************************************************************************
// BULK OUT Transfer - OUT Command Request on EP1, Pipe 0
//**********************************************************************************
BOOL BulkOut_CmdXfer(HWND hDlg, ULONG OutPktSize)
{
	BULK_TRANSFER_CONTROL bulkControl;
	HANDLE	hDevice = NULL;
	BOOLEAN	bResult = FALSE;
	int		i,nBytes = 0;	
	
	bulkControl.pipeNum = 0; // Endpoint #1 OUT
	for(i=0;i<(int)OutPktSize;i++)
		out1Buffer[i] = HostCommand[i];
						
	if(!bOpenDriver (&hDevice, pcDriverName))
	{
		MessageBox(hDlg, "EZ-USB Development Kit Not Found !","Error",MB_ICONSTOP);
		return FALSE; 
	}
	bResult = DeviceIoControl (	hDevice,
								IOCTL_EZUSB_BULK_WRITE,
								&bulkControl,
								sizeof(BULK_TRANSFER_CONTROL),
								&out1Buffer,
								OutPktSize,
								(unsigned long *)&nBytes,
								NULL); 	
	CloseHandle(hDevice);

	if(!bResult)
	{
		return FALSE;
	}

	return TRUE;					;
}

//**********************************************************************************
// BULK IN Transfer - IN Descriptor data on EP1, Pipe 1
//**********************************************************************************
BOOL BulkIn_CmdXfer(HWND hDlg)
{
	BULK_TRANSFER_CONTROL bulkControl;
	HANDLE	hDevice = NULL;
	BOOLEAN	bResult = FALSE;
	
	// Endpoint #1 IN
	bulkControl.pipeNum = 1;
	if(!bOpenDriver(&hDevice, pcDriverName))
	{
		MessageBox(hDlg, "EZ-USB Development Kit Not Found !","Error",MB_ICONSTOP);
		return FALSE; 
	}
	bResult = DeviceIoControl (	hDevice,
								IOCTL_EZUSB_BULK_READ,
								&bulkControl,
								sizeof(BULK_TRANSFER_CONTROL),
								&in1Buffer,
								DATA_BLOCK_SIZE,		// max IN size allowed
								(unsigned long *)&in1Bytes,	// actual bytes returned
								NULL);			
	CloseHandle(hDevice);

	if(!bResult)
	{
		return FALSE;
	}

	return TRUE;					
}

//******************************************************************************************
// Refresh - For sensing new device attachment - IN Data (state change to 1) on EP2, Pipe 2
//******************************************************************************************
void RefreshThread(LPVOID lpParameter)   // thread data
{
	HWND	hDlg = (HWND) lpParameter;
	BULK_TRANSFER_CONTROL bulkControl;
	HWND    hInfoBox	= NULL;
	HANDLE	hDevice		= NULL;
	BOOLEAN	bResult		= FALSE;
	int		refByte = 0;
	FLOAT	delaystart;
	
	hInfoBox = GetDlgItem (hDlg, IDC_INFO_BOX);
	
	bRefreshThread = TRUE;
	refData = 1; // do the initial refresh
	while(bRefreshThread)
	{
		// Ensure the refresh is updated when 1st launched, in case the SL811HS demo board is running already
		if(refData == 1)				
		{
		    EzSendMessage (hInfoBox, LB_RESETCONTENT, 0, 0);
			ezCMD = SL_REFRESH;
				// Endpoint #1 OUT
				if(!BulkOut_CmdXfer(hDlg, 2)) 
				{
					MessageBox(hDlg, "EZUSB-OUT(1) Failed (Refresh)","Error",MB_ICONSTOP);
					break;
				}

				delaystart = (FLOAT)GetTickCount();
				while(GetTickCount()-delaystart < 5);

				// Endpoint #1 IN 
				if(BulkIn_CmdXfer(hDlg)) 
					DispDevData(in1Buffer,in1Bytes,hInfoBox);
				else
				{
					MessageBox(hDlg, "EZUSB-IN(1) Failed (Refresh)","Error",MB_ICONSTOP);
					break;
				}		
			refData = 0;			// wait for next valid device attached/detached

		}

		bulkControl.pipeNum = 2; // Endpoint #2 IN
	    if(!bOpenDriver(&hDevice, pcDriverName))
		{
		  MessageBox(hDlg, "EZ-USB Development Kit Not Found !","Error",MB_ICONSTOP);
		  return; 
		}
		Pipe2InPended = 1;
		bResult = DeviceIoControl (	hDevice,
									IOCTL_EZUSB_BULK_READ,
									&bulkControl,
									sizeof(BULK_TRANSFER_CONTROL),
									&refData,				// valid data received from device
									1,						// max IN size allowed
									(unsigned long *)&refByte,	// actual bytes returned
									NULL);			
	    CloseHandle(hDevice);
		Pipe2InPended = 0;

	}

	return;					
}

//**********************************************************************************
// Main Dialog proc                              
//**********************************************************************************
BOOL CALLBACK bMainDlgProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	HWND    hDataBox						= NULL;
	HWND    hStatusBox                      = NULL;
	HWND    hInfoBox	                    = NULL;
	HANDLE  hDevice                         = NULL;
	BOOLEAN bResult                         = FALSE;
	int     nBytes                          = 0;
	HFONT   hFont                           = NULL;
	ULONG   ulLength                        = 0;
	char    temp1[256]= "";
	char    temp2[256]= "";
	char    strFileOut[256];
	//int		i;
	FLOAT	delaystart;
    char    tempbuff[256];
	BOOLEAN bUpdateDevAuto                  = TRUE;

	HWND    hDevInfo	                    = NULL;
	WPARAM MywParam = 0;
	UINT iLbSel = 0;
	UINT RetVal = 0;
	int ScanVal;
	UINT inEP;
	UINT inAddr;
    WORD maxSize;
    WORD reqSize;
	char    str[5][256];
	LPARAM tempParam;

	// Get a handle to the output box
	hDataBox = GetDlgItem (hDlg, IDC_DATA_BOX);
	hStatusBox = GetDlgItem (hDlg, IDC_STATUS_BOX);
	hInfoBox = GetDlgItem (hDlg, IDC_INFO_BOX);

	hDevInfo = GetDlgItem (hDlg, IDC_INFO_BOX);
	
	switch(message)
	{
		case WM_LBUTTONDOWN:
			break;
      
		case WM_INITDIALOG:
			SetDlgItemInt (hDlg,IDC_USB_ADDRESS,2,FALSE);
			SetDlgItemInt (hDlg,IDC_ENDPOINT_ADDR,1,FALSE);
			SetDlgItemInt (hDlg,IDC_DATA_SIZE,8,FALSE);
            SetDlgItemText (hDlg, IDC_FILE_OUT, "C:\\CYPRESS\\USB\\Util\\Test\\512_Count.hex");
            SetDlgItemText (hDlg, IDC_SAVE_OUT_FILE, "C:\\CYPRESS\\USB\\Util\\Test\\EZ811_Out.txt");
			
			CheckDlgButton(hDlg,IDC_IN,BST_CHECKED);
			CheckDlgButton(hDlg,IDC_INT_XFER,BST_CHECKED);
			CheckDlgButton(hDlg,IDC_REPEAT,BST_UNCHECKED);
			EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)" ");
			EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)" ");
			EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)ABOUT_BOX_STR_0);
			EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)ABOUT_BOX_STR_1);
		    sprintf(tempbuff,"  Built %s %s", build_time, build_date);
			EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)tempbuff);
			
			////////////////////////////////////////////////////////////////////////////////
			// get handles to the device 
			////////////////////////////////////////////////////////////////////////////////
			if (bOpenDriver (&hDevice, pcDriverName) != TRUE)
			{
				MessageBox(hDlg, "Please plug in development board,\nload firmware, and restart.",
					"EZ-811 Development Board Not Found",MB_ICONSTOP);
				exit(1);
			}

			CloseHandle (hDevice);


			Get_EZUSB_Device_Info(hDevice, hDlg);

			if (pInterface->NumberOfPipes != 5)
			{ // wrong firmware loaded
				MessageBox(hDlg, "Please load firmware and restart.",
					"EZ-811 ezhost Firmware not loaded",MB_ICONSTOP);
				exit(1);
			}

			CheckDlgButton(hDlg,IDC_UPDATE_DEVS_AUTO, BST_CHECKED); // Update Dev is ON by default
			_beginthread(RefreshThread,0,hDlg);


			break;
      
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				
				case IDC_INFO_BOX:
					tempParam = lParam;
					if(HIWORD(wParam) != 0x01)
					  break;
					iLbSel = SendMessage(hDevInfo, LB_GETCURSEL, 0, 0);
					if(iLbSel != -1)
					{
					  RetVal = SendMessage(hDevInfo, LB_GETTEXT, iLbSel, (LPARAM)temp1);
	                  ScanVal = sscanf(temp1, "%s %s %d %s %d %s %s %d", 
						  &str[0], &str[1], &inAddr, &str[2], &inEP, &str[3], &str[4], &maxSize);
					  if((ScanVal == 8)&&(inAddr <= MAX_ADDR)&&(inEP <= MAX_EP))
                      {
			            SetDlgItemInt (hDlg,IDC_USB_ADDRESS,inAddr,FALSE);
			            SetDlgItemInt (hDlg,IDC_ENDPOINT_ADDR,inEP,FALSE);
	                    reqSize = GetDlgItemInt (hDlg, IDC_DATA_SIZE, NULL, FALSE);
						//if(maxSize < reqSize)
			            SetDlgItemInt (hDlg,IDC_DATA_SIZE,maxSize,FALSE);
					    if(!strcmp(str[3], "IN"))
						{
			              CheckDlgButton(hDlg,IDC_IN,BST_CHECKED);
			              CheckDlgButton(hDlg,IDC_OUT,BST_UNCHECKED);
						}
						else
						{
			              CheckDlgButton(hDlg,IDC_IN,BST_UNCHECKED);
			              CheckDlgButton(hDlg,IDC_OUT,BST_CHECKED);
						}
					    if(!strcmp(str[4], "INT"))
						{
			              CheckDlgButton(hDlg,IDC_INT_XFER,BST_CHECKED);
			              CheckDlgButton(hDlg,IDC_BULK_XFER,BST_UNCHECKED);
						}
						else
						{
			              CheckDlgButton(hDlg,IDC_INT_XFER,BST_UNCHECKED);
			              CheckDlgButton(hDlg,IDC_BULK_XFER,BST_CHECKED);
						}
					  }
					}
					break;
				//----------------------------------------------------------------------------
				// Built Information
				//----------------------------------------------------------------------------
				case IDC_ABOUT:
					EzSendMessage(hStatusBox, LB_RESETCONTENT, 0, 0);
					EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)" ");
					EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)" ");
					EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)ABOUT_BOX_STR_0);
					EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)ABOUT_BOX_STR_1);
		            sprintf(tempbuff,"  Built %s %s", build_time, build_date);
			        EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)tempbuff);
					break;
       
				//----------------------------------------------------------------------------
				// Exit windows
				//----------------------------------------------------------------------------
				case IDCANCEL:
				case IDC_QUIT:
					if(IsDlgButtonChecked(hDlg,IDC_REPEAT)==BST_CHECKED)
					{
						MessageBox(hDlg, "Stop repeat transfer before quitting","Error",MB_ICONSTOP);
						break;
					}
	                if(nOpsPending)
					{
		              MessageBox(hDlg, "Operations are pending: Please disconnect the EZ-USB development board before pressing OK.","Error",MB_ICONSTOP);
					}

	                bRefreshThread = FALSE;
					delaystart = (FLOAT)GetTickCount();
				    while(GetTickCount()-delaystart < 5);
					AbortRefresh(hDlg, hDevice);
					delaystart = (FLOAT)GetTickCount();
				    while(GetTickCount()-delaystart < 500);
					EndDialog(hDlg,0);
					break;
					
				//----------------------------------------------------------------------------
				// Clear "USB Data Transfer" & "Descriptor" Windows
				//----------------------------------------------------------------------------
				case IDC_CLEAR:
					EzSendMessage (hDataBox, LB_RESETCONTENT, 0, 0);
					EzSendMessage (hStatusBox, LB_RESETCONTENT, 0, 0);
					break;

				//----------------------------------------------------------------------------
				// Additional buttons
				//----------------------------------------------------------------------------
				case IDC_UPDATE_DEVS_AUTO:
					pTh =  (CThreadInfo *)malloc(sizeof(CThreadInfo));
		            pTh->VenReq.request = SL_TOGGLE_DS_REFRESH;
					pTh->length = 1;
					_beginthread(Vend_CmdXfer,0,pTh);
					break;

				case IDC_RESET_EZ811:
					pTh =  (CThreadInfo *)malloc(sizeof(CThreadInfo));
		            pTh->VenReq.request = SL_RESET;
					pTh->length = 1;
			        CheckDlgButton(hDlg,IDC_UPDATE_DEVS_AUTO, BST_CHECKED);
	                CheckDlgButton(hDlg,IDC_REPEAT,BST_UNCHECKED);

					_beginthread(Vend_CmdXfer,0,pTh);
					break;

				case IDC_SHOW_REGS:
					pTh =  (CThreadInfo *)malloc(sizeof(CThreadInfo));
                    EzSendMessage(hStatusBox, LB_RESETCONTENT, 0, 0);
                    sprintf(tempbuff,"Show Regs:");
                    EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)tempbuff);
		            pTh->VenReq.request = SL_SHOW_REGS;
		            pTh->VenReq.direction = 0x01;

	                pTh->strpcDriverName = pcDriverName;
	                pTh->hOutputBox = hDataBox;
					pTh->hStatusBox = hStatusBox;
	                pTh->hDlg = hDlg;
		            pTh->length = 0x10;

					_beginthread(Vend_CmdXfer,0,pTh);
					break;

				case IDC_SAVE_OUTPUT:
					 GetDlgItemText (hDlg, IDC_SAVE_OUT_FILE, strFileOut, 256);
					 OnOutputSave(hDlg, hDataBox, strFileOut);
					break;
					
				case IDC_FILE_XFER:
					 GetDlgItemText (hDlg, IDC_FILE_OUT, strFileOut, 256);
					 OnFileTrans(hDlg, strFileOut);
					 //break; // "fall through" this case to do a transfer

				case IDC_REPEAT:
					//break; // "fall through" this case to do a transfer

				case IDC_SNGL_XFER:

					if(!GetUsbAddress(hDlg)) break;			// Get USB Address
					if(!GetEndpointNum(hDlg)) break;		// Get endpoint number
					if(!GetDataSize(hDlg)) break;			// Get data length
						
					if(ezADDR==1 && HUB)					// if requested address is a HUB	
					{
						EzSendMessage (hStatusBox, LB_RESETCONTENT, 0, 0);
						EzSendMessage (hStatusBox, LB_ADDSTRING, 0, (LPARAM)"USB address is a HUB device");
						break;
					}

					if(IsDlgButtonChecked(hDlg,IDC_BULK_XFER)==BST_CHECKED)
						ezTYPE = BULK;
					else if(IsDlgButtonChecked(hDlg,IDC_ISO_XFER)==BST_CHECKED)
						ezTYPE = ISOCHRONOUS;
					else if(IsDlgButtonChecked(hDlg,IDC_INT_XFER)==BST_CHECKED)
						ezTYPE = INTERRUPT;					// For interrupt trasnfer
	
					if(IsDlgButtonChecked(hDlg,IDC_REPEAT)==BST_CHECKED)
						ezREPEAT = 1;

					pTh =  (CThreadInfo *)malloc(sizeof(CThreadInfo));

		            pTh->VenReq.request = SL_DATA_XFER_START;
		            pTh->VenReq.value = ezADDR;
		            pTh->VenReq.index = ezENP;
		            pTh->VenReq.direction = IS_IN_EP(ezENP);
					

	                pTh->strpcDriverName = pcDriverName;
	                pTh->hOutputBox = hDataBox;
	                pTh->hDlg = hDlg;

		            pTh->length = ezLEN;

					if(LOWORD(wParam) == IDC_FILE_XFER)
					  pTh->fileXfer = 1;
					else
					  pTh->fileXfer = 0;

					if(LOWORD(wParam) != IDC_REPEAT)
	                  CheckDlgButton(hDlg,IDC_REPEAT,BST_UNCHECKED);

					_beginthread(Vend_CmdXfer,0,pTh);

					break;

				case IDC_REFRESH:

		            EzSendMessage (hInfoBox, LB_RESETCONTENT, 0, 0);

					pTh =  (CThreadInfo *)malloc(sizeof(CThreadInfo));

		            pTh->VenReq.request = SL_REFRESH;
		            pTh->VenReq.direction = 0x01;

	                pTh->strpcDriverName = pcDriverName;
					pTh->hInfoBox = hInfoBox;
	                pTh->hDlg = hDlg;
		            pTh->length = VEN_BUFF_SIZE;

					_beginthread(Vend_CmdXfer,0,pTh);

					break;
					
				//----------------------------------------------------------------------------
				// USB Data Transfer Control
				//----------------------------------------------------------------------------
				case IDC_INT_XFER:
					break;
				case IDC_BULK_XFER:
					break;				
				case IDC_ISO_XFER:
					break;					
				
				//----------------------------------------------------------------------------
				// Get Descriptors
				//----------------------------------------------------------------------------
				case IDC_DEV_DESCP:
				case IDC_CFG_DESCP:
				case IDC_CLASS_DESCP:
				case IDC_STR_DESCP:


	                CheckDlgButton(hDlg,IDC_REPEAT,BST_UNCHECKED);
					if(!GetUsbAddress(hDlg)) break;			// Get USB Address

					pTh =  (CThreadInfo *)malloc(sizeof(CThreadInfo));
					if(LOWORD(wParam) == IDC_DEV_DESCP)
					{
                      EzSendMessage(hStatusBox, LB_RESETCONTENT, 0, 0);
                      sprintf(tempbuff,"Get Device Descriptor:");
                      EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)tempbuff);
		              pTh->VenReq.request = SL_DEVICE_DESCP;
					}
					if(LOWORD(wParam) == IDC_CFG_DESCP)
					{
                      EzSendMessage(hStatusBox, LB_RESETCONTENT, 0, 0);
                      sprintf(tempbuff,"Get Config Descriptor:");
                      EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)tempbuff);
		              pTh->VenReq.request = SL_CONFIG_DESCP;
					}
					if(LOWORD(wParam) == IDC_CLASS_DESCP)
					{
                      EzSendMessage(hStatusBox, LB_RESETCONTENT, 0, 0);
                      sprintf(tempbuff,"Get Class Descriptor:");
                      EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)tempbuff);
		              pTh->VenReq.request = SL_CLASS_DESCP;
					}
					if(LOWORD(wParam) == IDC_STR_DESCP)
					{
                      EzSendMessage(hStatusBox, LB_RESETCONTENT, 0, 0);
                      sprintf(tempbuff,"Get String Descriptor:");
                      EzSendMessage(hStatusBox, LB_ADDSTRING, 0, (LPARAM)tempbuff);
		              pTh->VenReq.request = SL_STRING_DESCP;
					}

		            pTh->VenReq.value = ezADDR;
		            pTh->VenReq.direction = 0x01;

	                pTh->strpcDriverName = pcDriverName;
	                pTh->hOutputBox = hDataBox;
					pTh->hStatusBox = hStatusBox;
	                pTh->hDlg = hDlg;
		            pTh->length = VEN_BUFF_SIZE;

					_beginthread(Vend_CmdXfer,0,pTh);

					break;

			} /*end switch wParam*/
    
       break;          
          
    } /*end switch message*/
    
    return FALSE;
    
} /*end MainDlgProc*/


//**********************************************************************************
// Check USB address entry
//**********************************************************************************
BOOL GetUsbAddress(HWND hDlg)
{
	HWND    hStatusBox  = NULL;
	hStatusBox = GetDlgItem (hDlg, IDC_STATUS_BOX);
	
	ezADDR = GetDlgItemInt (hDlg, IDC_USB_ADDRESS, NULL, FALSE);
	if( ezADDR>=1 && ezADDR<=5)
		return TRUE;
	else
	{
		EzSendMessage (hStatusBox, LB_RESETCONTENT, 0, 0);
		EzSendMessage (hStatusBox, LB_ADDSTRING, 0, (LPARAM)"USB address must be from 1~5");
		return FALSE;
	}
	
}

//**********************************************************************************
// Check Endpoint Number entry
//**********************************************************************************
BOOL GetEndpointNum(HWND hDlg)
{
	ezENP = GetDlgItemInt (hDlg, IDC_ENDPOINT_ADDR, NULL, FALSE);
	if(IsDlgButtonChecked(hDlg,IDC_IN)==BST_CHECKED)
		ezENP |= 0x80;
	else if(IsDlgButtonChecked(hDlg,IDC_OUT)==BST_CHECKED)
		ezENP &= ~0x80;
	return TRUE;
}

//**********************************************************************************
// Check data size entry
//**********************************************************************************
///*
BOOL GetDataSize(HWND hDlg)
{

	ezLEN = GetDlgItemInt (hDlg, IDC_DATA_SIZE, NULL, FALSE);

	if(ezLEN==0)
	{
		MessageBox(hDlg, "Data size must be non-zero","Error",MB_ICONSTOP);
		return FALSE;
	}
	else if(ezLEN>MAX_EP0_PAYLOAD)
	{
		MessageBox(hDlg, "Data Transfers are limited to 64 bytes","Error",MB_ICONSTOP);
		ezLEN = MAX_EP0_PAYLOAD;
		SetDlgItemInt (hDlg,IDC_DATA_SIZE,ezLEN,FALSE);
		return TRUE;
	}
	else
		return TRUE;

	
}
//*/  
//**********************************************************************************
// bOpenDriver proc                              
//**********************************************************************************
BOOLEAN bOpenDriver (HANDLE * phDeviceHandle, PCHAR devname)
{
   char completeDeviceName[64] = "";
   char pcMsg[64] = "";
   
   strcat (completeDeviceName,
      "\\\\.\\"
      );
   
   strcat (completeDeviceName,
		    devname
          );
   
   *phDeviceHandle = CreateFile(   completeDeviceName,
      GENERIC_WRITE,
      FILE_SHARE_WRITE,
      NULL,
      OPEN_EXISTING,
      0,
      NULL);
   
   if (*phDeviceHandle == INVALID_HANDLE_VALUE)
      return (FALSE);

   else 
      return (TRUE);
      
}   

//**********************************************************************************
// millisecond delay
//**********************************************************************************
void msDelay(ULONG time)
{
	ULONG StartTime;

	StartTime = (ULONG)GetTickCount();
	while( ((ULONG)GetTickCount()-StartTime) != time);
}

//**********************************************************************************
// Display USB data to Data Windows
//**********************************************************************************
#define dBYTES_PER_LINE 0x08
void DispDataBox(PVOID pvBuffer, ULONG length, HWND hOutputBox1)
{
	int                    nItems    = 0;
	char                   temp[64]  = "";
	char                   temp2[64]  = "";
	ULONG	i;
	ULONG   j;
	PUCHAR	ptr;
   
	ptr = (PUCHAR) pvBuffer;

	if(ptr[0]==XFERSTOP0 && ptr[1]==XFERSTOP1 && length==2)
	{
		bDataXferThread = FALSE;
		EzSendMessage (hOutputBox1, LB_ADDSTRING, 0, (LPARAM)"Repeat data transfer stopped");
	}

	else if(ptr[0]==NONEXIST0 && ptr[1]==NONEXIST1 && length==2)
	{
		bDataXferThread = FALSE;
		EzSendMessage (hOutputBox1, LB_ADDSTRING, 0, (LPARAM)"USB device does not exist");
		EzSendMessage (hOutputBox1, LB_ADDSTRING, 0, (LPARAM)"Repeat data transfer stopped");
	}

	else
	{
		for (i = 0; i < ((length + dBYTES_PER_LINE - 1) / dBYTES_PER_LINE); i++)
		{
			sprintf(temp,"");
			switch(ezTYPE)
			{
				case ISOCHRONOUS:	sprintf(temp,"ISO"); break;
				case BULK:			sprintf(temp,"BULK"); break;
				case INTERRUPT:		sprintf(temp,"INTR"); break;
			}
			if(ezENP&0x80)
				sprintf(temp2,"-IN   : "); 
			else
				sprintf(temp2,"-OUT: "); 
			strcat(temp,temp2);
				
			for (j = 0; j < dBYTES_PER_LINE; j++)
			{
				if (((i * dBYTES_PER_LINE) + j) < length)
				{
					sprintf(temp2,"%02X ",*ptr++);
					strcat(temp,temp2);
				}
			}

			EzSendMessage (hOutputBox1, LB_ADDSTRING, 0, (LPARAM)temp);
		}
	}
	

}

//**********************************************************************************
// Dumping raw descriptor data to Status Windows
//**********************************************************************************
#define sBYTES_PER_LINE 0x08
void DumpStatusBox(PVOID pvBuffer, ULONG length, HWND hOutputBox)
{
	int                    nItems    = 0;
	char                   temp[64]  = "";
	char                   temp2[64]  = "";
	ULONG	i,j;
	PUCHAR	ptr;
   
   ptr = (PUCHAR) pvBuffer;

   for (i = 0; i < ((length + sBYTES_PER_LINE - 1) / sBYTES_PER_LINE); i++)
   {
      wsprintf(temp,"%03X: ",(i*sBYTES_PER_LINE));
      for (j = 0; j < sBYTES_PER_LINE; j++)
      {
         if (((i * sBYTES_PER_LINE) + j) < length)
         {
            wsprintf(temp2,"%02X ",*ptr++);
            strcat(temp,temp2);
         }
      }
      EzSendMessage (hOutputBox, LB_ADDSTRING, 0, (LPARAM)temp);
   }
}

//**********************************************************************************
// Dumping String to Status Windows
//**********************************************************************************
void DumpString(PVOID pvBuffer, ULONG length, HWND hOutputBox)
{
	int                    nItems    = 0;
	char                   temp[64]  = "";
	char                   temp2[64]  = "";
	PUCHAR	ptr;
	int		i,len;
   
	ptr = (PUCHAR) pvBuffer;
	len = (int)ptr[0];
	
	if(!ptr[2])				// if 3rd byte is a zero, i.e. error in string
		EzSendMessage (hOutputBox, LB_ADDSTRING, 0, (LPARAM)"No String");   		

	else
	{
		for(i=2;i<len;i+=2)
		{
			sprintf(temp2,"%c",ptr[i]);
			strcat(temp,temp2);
		}
		EzSendMessage (hOutputBox, LB_ADDSTRING, 0, (LPARAM)temp);   
	}
}

//**********************************************************************************
// Display USB info data (all endpoints) to Info Window
//**********************************************************************************
void DispDevData(PVOID pvBuffer, ULONG length, HWND hOutputBox)
{
	int     nItems		= 0;
	char    temp[256]	= "";
	char    temp2[64]	= "";
	char	vend[256]	= "";
	char	vend2[64]	= "";
	ULONG	i,cnt,vid;
	PUCHAR	ptr;
	PUCHAR	ptrmax;
	ULONG NumDataEp;

	if(length < 2)
		return; // don't print invalid info
   
	ptr = (PUCHAR) pvBuffer;
	ptrmax = (PUCHAR) pvBuffer;
	ptrmax += length;
	for(ptr = (PUCHAR) pvBuffer; (ptr < ptrmax) && ptr[0]; ptr+=cnt) // itterate through addresses
	{
		// USB Device Updates
		sprintf(temp,"USB Address %d, ",ptr[0]);				// USB Address
		if(ptr[1])
		{
			sprintf(temp2,"Port %d ",ptr[1]);					// Hub Port Number
			strcat(temp,temp2);				
		}
		if(ptr[2])
			strcat(temp," (Low Speed - ");						// DeviceSpeed
		else
			strcat(temp," (Full Speed - ");
		switch(ptr[3])
		{
			case 0x01:	strcat(temp,"AUD)"); break;				// Class Type
			case 0x0A:
			case 0x02:	strcat(temp,"COM)"); break;
			case 0x03:	strcat(temp,"HID)"); break;
			case 0x05:	strcat(temp,"PHY)"); break;
			case 0x07:	strcat(temp,"PRN)"); break;
			case 0x08:	strcat(temp,"MSC)"); break;
			case 0x09:	strcat(temp,"HUB)"); break;
			case 0x0B:	strcat(temp,"SMC)"); break;
			case 0x0D:	strcat(temp,"SEC)"); break;
			case 0xFF:	strcat(temp,"VEN)"); break;
			default:strcat(temp,"STD)"); break;
		}		
		EzSendMessage (hOutputBox, LB_ADDSTRING, 0, (LPARAM)temp);	

		sprintf(vend, "-- Vendor ID  : ");
		sprintf(vend2,"0x%02X%02X",ptr[5],ptr[4]);	// VID hex code
		vid = (ptr[5]*256) + ptr[4];				// VID value		
		switch(vid)		
		{
			case 0x03ee: strcat(vend,vend2); strcat(vend," - Mitsumi"); break;	
			case 0x03f0: strcat(vend,vend2); strcat(vend," - Hewlett-Packard"); break;
		  	case 0x03f3: strcat(vend,vend2); strcat(vend," - Adaptec"); break;
			case 0x040a: strcat(vend,vend2); strcat(vend," - Kodak"); break;
			case 0x041e: strcat(vend,vend2); strcat(vend," - Creative"); break;
			case 0x0423: strcat(vend,vend2); strcat(vend," - CATC"); break;
			case 0x042b: strcat(vend,vend2); strcat(vend," - Intel"); break;
			case 0x0446: strcat(vend,vend2); strcat(vend," - NMB"); break;
		  	case 0x045e: strcat(vend,vend2); strcat(vend," - Microsoft"); break;
			case 0x046d: strcat(vend,vend2); strcat(vend," - Logitech"); break;
			case 0x046e: strcat(vend,vend2); strcat(vend," - BTC"); break;
			case 0x047c: strcat(vend,vend2); strcat(vend," - Dell"); break;
			case 0x047b: strcat(vend,vend2); strcat(vend," - Silitek"); break;
			case 0x049f: strcat(vend,vend2); strcat(vend," - Compaq"); break;
			case 0x04b0: strcat(vend,vend2); strcat(vend," - Nikon"); break;
			case 0x04b3: strcat(vend,vend2); strcat(vend," - IBM"); break;
			case 0x04cb: strcat(vend,vend2); strcat(vend," - Fuji"); break;
			case 0x04d2: strcat(vend,vend2); strcat(vend," - Altec Lansing"); break;
			case 0x0500: strcat(vend,vend2); strcat(vend," - SUH"); break;
			case 0x059b: strcat(vend,vend2); strcat(vend," - Iomega"); break;
			case 0x05ac: strcat(vend,vend2); strcat(vend," - Apple"); break;				
			case 0x06cd: strcat(vend,vend2); strcat(vend," - Keyspan"); break;
			case 0x08ff: strcat(vend,vend2); strcat(vend," - AuthenTec"); break;
			case 0x0a86: strcat(vend,vend2); strcat(vend," - SecuGen"); break;
			case 0x0472: case 0x04f2: strcat(vend,vend2); strcat(vend," - Chicony"); break;
		  	case 0x04c1: case 0x0506: strcat(vend,vend2); strcat(vend," - 3Com"); break;
			case 0x0471: case 0x04cc: strcat(vend,vend2); strcat(vend," - Philips"); break;
			case 0x0445: case 0x047e: strcat(vend,vend2); strcat(vend," - Lucent"); break;
			case 0x0781: case 0x0871: strcat(vend,vend2); strcat(vend," - SanDisk"); break;
			case 0x0547: case 0x04ce: case 0x05ab:
		  	case 0x04b4: strcat(vend,vend2); strcat(vend," - Cypress"); break;
			default:	 strcat(vend,vend2); strcat(vend," - Undefined"); break;
		}
		EzSendMessage (hOutputBox, LB_ADDSTRING, 0, (LPARAM)vend);

		sprintf(temp,"-- Product ID : 0x%02X%02X",ptr[7],ptr[6]);	// PID
		EzSendMessage (hOutputBox, LB_ADDSTRING, 0, (LPARAM)temp);
		sprintf(temp,"-- EP0 Max.   : %d bytes",ptr[8]);			// bMaxPacketSize0
		EzSendMessage (hOutputBox, LB_ADDSTRING, 0, (LPARAM)temp);
		
		// USB Data Endpoint Updates
		NumDataEp = ptr[9];
		cnt = 10;

		for(i=0;i<NumDataEp;i++)
		{
	      sprintf (temp, "-- EP %d - %d %s %s %3d-byte",  ptr[0],
		  ptr[cnt]&0x0F, PIPE_DIRECTION[ptr[cnt] >> 7],
		  PIPE_TYPE_STRINGS[ptr[cnt+1]&0x03], (ptr[cnt+2] + ptr[cnt+3]*256));
	      EzSendMessage (hOutputBox, LB_ADDSTRING, 0, (LPARAM)temp);// display all strings
		  cnt += 5;												// next next endpoint
		}
		EzSendMessage (hOutputBox, LB_ADDSTRING, 0, (LPARAM)" ");
	}		
}

//**********************************************************************************
// ESUSB Host Device Handle
//**********************************************************************************
void Get_EZUSB_Device_Info(HANDLE hDevice, HWND hDlg)
{
	PVOID   pvBuffer                        = 0;
	PVOID   pdBuffer                        = 0;
	HWND    hOutputBox                      = NULL;
	BOOLEAN bResult                         = FALSE;
	int     nBytes                          = 0;
	int     nItems                          = 0;
	HFONT   hFont                           = NULL;
	ULONG   ulLength                         = 0;

	PUSBD_PIPE_INFORMATION pPipe;
	
	pvBuffer = (void*)malloc (sizeof(Usb_String_Descriptor) + 128);
	pdBuffer = (void*)malloc (sizeof(Usb_Device_Descriptor) + 128);
	hOutputBox = GetDlgItem (hDlg, IDC_STATUS_BOX);
	
	////////////////////////////////////////////////////////////////////////////////
	// Get VID/PID from Device Descriptor
	////////////////////////////////////////////////////////////////////////////////
	if (bOpenDriver (&hDevice, pcDriverName) != TRUE)
	{
		MessageBox(hDlg, "EZ-USB Development Kit Not Found !","Error",MB_ICONSTOP);
		return;
	}
	bResult = DeviceIoControl (	hDevice,
								IOCTL_Ezusb_GET_DEVICE_DESCRIPTOR,
								pdBuffer,
								sizeof (Usb_Device_Descriptor),
								pdBuffer,
								sizeof (Usb_Device_Descriptor),
								(unsigned long *)&nBytes,
								NULL);
	CloseHandle (hDevice);	// Close the handle

	if (bResult!=TRUE)	
		MessageBox(hDlg, "Get VID/PID Failed","Error",MB_ICONSTOP);
						
	////////////////////////////////////////////////////////////////////////////////
	// Get Pipes Info
	////////////////////////////////////////////////////////////////////////////////
	if (bOpenDriver (&hDevice, pcDriverName) != TRUE)
	{
		MessageBox(hDlg, "EZ-USB Development Kit Not Found !","Error",MB_ICONSTOP);
		return;
	}
	bResult = DeviceIoControl (hDevice,
				IOCTL_Ezusb_GET_PIPE_INFO,
				NULL,
				0,
				InterfaceInfo,
				sizeof(InterfaceInfo),
				(unsigned long *)&nBytes,
				NULL);
	CloseHandle (hDevice);	// Close the handle
						
	if (bResult==TRUE)
	{
		pInterface = (PUSBD_INTERFACE_INFORMATION) InterfaceInfo;
		pPipe = pInterface->Pipes;
	}
	else
		MessageBox(hDlg, "Get Pipe Info Failed","Error",MB_ICONSTOP);

	free (pvBuffer);		// Free the memory
}

void AbortRefresh(HWND hDlg, HANDLE hDevice)
{
	BOOLEAN bResult = FALSE;
	ULONG pipenum;
	int nBytes= 0;

	if(!Pipe2InPended)
		return;

		pipenum = 2; // Endpoint #2 IN
	    if(!bOpenDriver(&hDevice, pcDriverName))
		{
		  MessageBox(hDlg, "EZ-USB Development Kit Not Found !","Error",MB_ICONSTOP);
		  return; 
		}
					bResult = DeviceIoControl (hDevice,
						IOCTL_Ezusb_ABORTPIPE,
						&pipenum,
						sizeof(ULONG),
						NULL,
						0,
						(unsigned long *)&nBytes,
						NULL);
	    CloseHandle(hDevice);

		if(!bResult)
		{
			MessageBox(hDlg, "EZUSB-IN(2) Failed Abort","Error",MB_ICONSTOP);
		}
}

void EzSendMessage(HWND hLb, int OpType, int OtherOp, LPARAM pStr)
{
	int nItems = 0;
	if(OpType == LB_ADDSTRING)
	{
		nItems = SendMessage (hLb, LB_GETCOUNT, 0, 0);
		if (nItems == MAX_ITEMS_IN_LB)
		{
			SendMessage (hLb, LB_DELETESTRING, 0, 0);
		}
	}
	SendMessage(hLb, OpType, OtherOp, pStr);
	SendMessage(hLb, LB_SETTOPINDEX, nItems, 0);
}

void OnFileTrans(HWND hDlg, char* pFile)
{
	FILE *fp;

	fp = fopen(pFile,"rb");
    if(!fp)
    {
        MessageBox(hDlg, "Error opening data file","Error",MB_ICONSTOP);
		return;
    }
    fileXferBytes = fread(FileXferBuff, sizeof(unsigned char), MAX_FILE_SIZE, fp);
    fclose(fp);

	if(!fileXferBytes)
	{
		return;
	}

}


void OnOutputSave(HWND hDlg, HWND hDataBox, char* pFile)
{
	FILE *fp;
	int fileWriteBytes;
	int nItems = 0;
	int i;
	char strText[256];
	int RetVal;

	fp = fopen(pFile,"w");
    if(!fp)
    {
        MessageBox(hDlg, "Error opening file for output","Error",MB_ICONSTOP);
		return;
    }

	nItems = SendMessage (hDataBox, LB_GETCOUNT, 0, 0);
	for(i=0;i<nItems;i++)
	{
      RetVal = SendMessage(hDataBox, LB_GETTEXT, i, (LPARAM)strText);
	  if(RetVal)
	  {
		strcat(strText, "\n");
        fileWriteBytes = fwrite(strText, sizeof(char), strlen(strText), fp);
        if(!fileWriteBytes)
		{
          MessageBox(hDlg, "Error saving file","Error",MB_ICONSTOP);
		}
	  }
	}

    fclose(fp);

}
