#pragma NOIV					            // Do not generate interrupt vectors
////////////////////////////////////////////////////////////////////////////////
// File:		host2131.c
// Purpose:	    8051 firmware to master SL811 Embedded Host.
//              Derived from periph.c frameworks file.
//              Contains USB peripheral-related firmware.
//              Contains PC host command interface.
//              Based on SL811HST code written by cxn.
//
// $Header: /USB/ez811/firmware/Emb_Host/host2131.c 8     5/17/02 6:09p Tpm $
// Copyright (c) 2002 Cypress Semiconductor. May not be reproduced without permission.
// See the license agreement for more details.
////////////////////////////////////////////////////////////////////////////////

#include "ezusb.h"
#include "ezregs.h"
#include "host_811.h"

extern BOOL	GotSUD;			// Received setup data flag
extern BOOL	Sleep;
extern BOOL	Rwuen;
extern BOOL	Selfpwr;

extern BOOL SLAVE_ENUMERATED;
extern BOOL	BULK_OUT_DONE;
extern BOOL DESC_XFER;
extern BOOL DATA_XFER;
extern xdata BYTE DataBufLen;
extern xdata BYTE DBUF[];
extern xdata BYTE HOSTCMD[];
extern xdata BYTE REGBUFF[];
extern xdata BYTE remainder;
extern void sl811h_init(void);
extern int slave_detect(void);
extern BOOL	CONFIG_DONE;

extern BOOL DATA_XFER_OUT;
extern xdata BYTE DBUFOut[];
extern BOOL dsPoll;
extern BOOL bDataToggle;

extern xdata pDevDesc  	pDev;			// Device descriptor struct
extern xdata pCfgDesc  	pCfg;			// Config descriptor struct
extern xdata pStrDesc 	pStr;			// String descriptor struct
extern xdata pHidDesc 	pHid;			// HID class descriptor struct
extern xdata pHubDesc 	pHub;			// HUD class descriptor struct
extern xdata pIntfDesc 	pIfc;			// Interface descriptor struct
extern xdata pHUBDEV    uHub;			// Struct for downstream device on HUB
extern xdata pUSBDEV    uDev[];	// Multiple USB devices attributes, Max 5 devices

void dsOut(void);
int DataRW(BYTE usbaddr, BYTE epaddr, WORD wPayload, WORD wLen, BYTE *pData);
WORD GetDevInfo(BYTE *DevInfo);

int	desc_next;
int	data_next;
void TD_Poll(void);

BYTE	Configuration;		// Current configuration
BYTE	AlternateSetting;	// Alternate settings

//-----------------------------------------------------------------------------
// Task Dispatcher hooks
//	The following hooks are called by the task dispatcher.
//-----------------------------------------------------------------------------
// IN2 	=>  1 bytes max, Refresh data update from ezusb to host
//-----------------------------------------------------------------------------
void TD_Init(void) 				// Called once at startup
{
	Rwuen = TRUE;				// Enable remote-wakeup
	ISOCTL |= 0x01;				// free up iso endpoints for external data space (1024)

	IN07VAL |= bmEP1;			// Enable endpoint 1 IN
	IN07VAL |= bmEP2;			// Enable endpoint 2 IN
	IN07VAL |= bmEP3;			// Enable endpoint 3 IN
	OUT07VAL |= bmEP1;			// Enable endpoint 1 OUT 
   	OUT07IEN |= bmEP1;			// Enable endpoint 1 OUT interrupt
	OUT1BC = 0;					// Arm Endpoint 1 OUT to recieve data
	OUT07VAL |= bmEP3;			// Enable endpoint 3 OUT 
   	OUT07IEN |= bmEP3;			// Enable endpoint 3 OUT interrupt
	OUT3BC = 0;					// Arm Endpoint 3 OUT to recieve data
	
	BPADDR = (WORD)TD_Poll;     // Setup breakpoint to trigger on TD_Poll()
	USBBAV |= bmBPEN;			// Enable the breakpoint
	USBBAV &= ~bmBPPULSE;

	sl811h_init();				// setup SL811H chip variables
	desc_next = 0;
	data_next = 0;

}

//*****************************************************************************************
// ENDPOINT FUNCTION :
// EP2-IN  -> Return a byte of 0x01 to ezusb host to indicate a attach/detach for refresh
//*****************************************************************************************
void TD_Poll(void) 
{
	int	i,count;
    BYTE DescBufLen;		    // EZUSB's IN #1 descriptor buffer length

	slave_detect();				// Poll for any slave USB device attached to "SL811HS" Embedded Host

    if(BULK_OUT_DONE && !DESC_XFER)
    {
			BULK_OUT_DONE = FALSE;
				switch(HOSTCMD[0])							// type of commands from EZUSB host
				{
					case SL_REFRESH:
	                    DescBufLen = GetDevInfo(DBUF);
                        if(!DescBufLen)				
                        { // there is nothing to transfer - keep the host app from pending
	                      DBUF[0] = 0;		
	                      DescBufLen = 1;			// arming the IN1 is done in the slave_detect loop                        
                        }
						DESC_XFER = TRUE;					// set DESC_XFER to start transfer
						break;

					default: break;							// default break;
                }
    }

	if(DESC_XFER && !(IN1CS & bmEPBUSY))
	{													// ensure DESC_XFER & IN1 not busy
		if(DescBufLen)									// check for any data length
		{												//
			count = (int)((DescBufLen>=64) ? 64:DescBufLen);	// select data length, max allowed is 64 bytes
			for(i=0; i<count; i++)						// copy data into IN buffer
				IN1BUF[i] = DBUF[i+desc_next];			// 
			IN1BC = count;								// arm IN data transfer
			DescBufLen -= count;						// update remaining data len
			desc_next += count;
            if(!DescBufLen)
            {
			  desc_next = 0;
			  DESC_XFER = FALSE;					    // reset DESC_XFER to stop transfer
            }
		}
	}
}

//---------------------------------------
BOOL TD_Suspend(void) 			// Called before the device goes into suspend mode
{
	return(TRUE);
}

BOOL TD_Resume(void) 			// Called after the device resumes
{
	return(TRUE);
}

//-----------------------------------------------------------------------------
// Device Request hooks
//	The following hooks are called by the end point 0 device request parser.
//-----------------------------------------------------------------------------

BOOL DR_GetDescriptor(void)
{
	return(TRUE);
}

BOOL DR_SetConfiguration(void)	// Called when a Set Configuration command is received
{
	Configuration = SETUPDAT[2];
   CONFIG_DONE = TRUE;
	return(TRUE);				// Handled by user code
}

BOOL DR_GetConfiguration(void)	// Called when a Get Configuration command is received
{
	IN0BUF[0] = Configuration;
	EZUSB_SET_EP_BYTES(IN0BUF_ID,1);
	return(TRUE);				// Handled by user code
}

BOOL DR_SetInterface(void) 		// Called when a Set Interface command is received
{
	AlternateSetting = SETUPDAT[2];
	return(TRUE);				// Handled by user code
}

BOOL DR_GetInterface(void) 		// Called when a Set Interface command is received
{
	IN0BUF[0] = AlternateSetting;
	EZUSB_SET_EP_BYTES(IN0BUF_ID,1);
	return(TRUE);				// Handled by user code
}

BOOL DR_GetStatus(void)
{
	return(TRUE);
}

BOOL DR_ClearFeature(void)
{
	return(TRUE);
}

BOOL DR_SetFeature(void)
{
	return(TRUE);
}

#define EP0BUFF_SIZE	0x40

BOOL DR_VendorCmnd(void)
{
  WORD addr, len, bc;
  BYTE EpAddr, EpIdx;
  WORD i;
  BYTE RegAddr;
  xdata BYTE OUT_DATA[EP0BUFF_SIZE];	// OUT data buffer
  int retDataRW = FALSE;
  BYTE DescBufLen = 0;
  WORD ReqLen = 0;

  switch(SETUPDAT[1])
  { // NOTE" 0xA0 is reserved: 0xA0 = Anchor Download (handled by core)
    case SL_RESET:
	{
      sl811h_init();            // initialize SL811HST
      *IN0BUF = SETUPDAT[1];    // return command type
      IN0BC = 0x01;             // arm endp, # bytes to xfr
      EP0CS |= bmBIT1;          // ack handshake phase of device request
      break;
    }
    case SL_DEVICE_DESCP:                                      // GetDevDesc
    case SL_CONFIG_DESCP:                                      // GetConfDesc
    case SL_CLASS_DESCP:                                      // GetClassDesc
    case SL_STRING_DESCP:                                      // GetStringDesc
	{
		EpAddr = SETUPDAT[2];		                // Get address
		ReqLen = SETUPDAT[6];
		ReqLen |= SETUPDAT[7] << 8;                    // Get requested length

		if(SETUPDAT[1] == SL_DEVICE_DESCP)
		{
		  pDev =(pDevDesc)DBUF;
		  if(GetDesc(EpAddr,DEVICE,0,18,DBUF))	    // Device Descp - 18 bytes 
		    DescBufLen = (WORD)pDev->bLength;		// update buffer length 
		}
		if(SETUPDAT[1] == SL_CONFIG_DESCP)
		{
		  pCfg =(pCfgDesc)DBUF;				
		  if (GetDesc(EpAddr,CONFIGURATION,0,255,DBUF))
		    DescBufLen = WordSwap(pCfg->wLength); 				
		}
		if(SETUPDAT[1] == SL_CLASS_DESCP)
		{
          if (GetDesc(EpAddr,CONFIGURATION,0,255,DBUF))	// Configuration Descp
          {
	        pIfc = (pIntfDesc)(DBUF + 9);				// point to Interface Descp
            if(pIfc->iClass==HIDCLASS)			// HID_CLASS
            {
              pHid = (pHidDesc)(DBUF + 9 + 9);		// get HID's report descriptor
              DescBufLen = (pHid->wItemLength <= 255) ? pHid->wItemLength : 255; 
              if(!GetHid_Desc(EpAddr,HID_REPORT,DescBufLen,DBUF))
                DescBufLen = 0;
            }
            else if(pIfc->iClass==HUBCLASS)		// HUB_CLASS
            {
              pHub =(pHubDesc)DBUF;					// get HUB class descriptor
              DescBufLen = (pHub->bLength <= 255) ? pHub->bLength : 255; 
              if(!GetHubDesc(EpAddr,0,9,DBUF)) 
                DescBufLen = 0;
            }
			else
                DescBufLen = 0;                 // Undefined Class
          }
		}
		if(SETUPDAT[1] == SL_STRING_DESCP)
		{
          pStr = (pStrDesc)DBUF;
          pStr->bLength = 0;
          if(GetDesc(EpAddr,(WORD)(0x02<<8)|STRING,0x0904,4,DBUF)) 
          { // get iManufacturer
			DescBufLen = pStr->bLength; // set string length			
            if(!GetDesc(EpAddr,(WORD)(0x02<<8)|STRING,0x0904,pStr->bLength,DBUF)) 		
              DescBufLen = 0;
          }
		}

		addr = DBUF;
		len = (DescBufLen<ReqLen) ? DescBufLen : ReqLen;
		if(SETUPDAT[0] == 0xC0)         // if (DIR=IN)
		{
			while(len)					// Move requested data through EP0IN one packet at a time.
			{
				if(len < EP0BUFF_SIZE)
					bc = len;
				else
					bc = EP0BUFF_SIZE;

				for(i=0; i<bc; i++)
						*(IN0BUF+i) = *((BYTE xdata *)addr+i);
				IN0BC = (BYTE)bc;       // Arm endpoint
				addr += bc;
				len -= bc;
				while(EP0CS & 0x04);    // Wait for INBSY to clear
			}
            IN0BC = 0x00;             // arm endp, # bytes to xfr
            EP0CS |= bmBIT1;          // ack handshake phase of device request
		}
		break;
    }
    case SL_REFRESH:
	{
		addr = DBUF;
	    len = GetDevInfo(DBUF);

		if(SETUPDAT[0] == 0xC0)         // if (DIR=IN)
		{
			while(len)					// Move requested data through EP0IN one packet at a time.
			{
				if(len < EP0BUFF_SIZE)
					bc = len;
				else
					bc = EP0BUFF_SIZE;

				for(i=0; i<bc; i++)
						*(IN0BUF+i) = *((BYTE xdata *)addr+i);
				IN0BC = (BYTE)bc;       // Arm endpoint
				addr += bc;
				len -= bc;
				while(EP0CS & 0x04);    // Wait for INBSY to clear
			}
            IN0BC = 0x00;             // arm endp, # bytes to xfr
            EP0CS |= bmBIT1;          // ack handshake phase of device request
		}
      break;
    }

    case SL_DATA_XFER_START:                  // Data Transfer with ds Dev
	{
		EpAddr = SETUPDAT[2];		// Get address and length
		EpIdx = SETUPDAT[4];
		len = SETUPDAT[6];

		addr = OUT_DATA;
		if(SETUPDAT[0] == 0xC0)         // if (DIR=IN)
		{
	        retDataRW = DataRW(EpAddr,EpIdx,64,len,OUT_DATA);
            if((remainder) && (remainder < len))
              len -= remainder;
			if(!retDataRW)
			{
				bc = 0;
				IN0BC = (BYTE)bc;       // Arm endpoint
				while(EP0CS & 0x04);    // Wait for INBSY to clear
				break;
			}
			while(len)					// Move requested data through EP0IN 
			{							// one packet at a time.

				if(len < EP0BUFF_SIZE)
					bc = len;
				else
					bc = EP0BUFF_SIZE;

					for(i=0; i<bc; i++)
						*(IN0BUF+i) = *((BYTE xdata *)addr+i);

				IN0BC = (BYTE)bc;       // Arm endpoint

				addr += bc;
				len -= bc;

				while(EP0CS & 0x04);    // Wait for INBSY to clear
			}
		}
		else if(SETUPDAT[0] == 0x40)    // if (DIR=OUT)
		{
			while(len)					// Move new data through EP0OUT 
			{							// one packet at a time.
				OUT0BC = 0;  // Clear bytecount to allow new data in; also stops NAKing

				while(EP0CS & 0x08);

				bc = OUT0BC; // Get the new bytecount

					for(i=0; i<bc; i++)
						 *((BYTE xdata *)addr+i) = *(OUT0BUF+i);

				addr += bc;
				len -= bc;
			}
	       retDataRW = DataRW(EpAddr,EpIdx,64,bc,OUT_DATA);
		}
		break;
    }
    case SL_TOGGLE_DS_REFRESH:
	{
	  dsPoll = !dsPoll;         // toggle downstream poll
      *IN0BUF = SETUPDAT[1];    // return command type
      IN0BC = 0x01;             // arm endp, # bytes to xfr
      EP0CS |= bmBIT1;          // ack handshake phase of device request
      break;
    }

    case SL_SHOW_REGS:
	{
		addr = REGBUFF;
		len = 16;
		for(RegAddr=0; RegAddr<len; RegAddr++)
          REGBUFF[RegAddr] = SL811Read(RegAddr);

		if(SETUPDAT[0] == 0xC0)         // if (DIR=IN)
		{
			while(len)					// Move requested data through EP0IN one packet at a time.
			{
				if(len < EP0BUFF_SIZE)
					bc = len;
				else
					bc = EP0BUFF_SIZE;

				for(i=0; i<bc; i++)
						*(IN0BUF+i) = *((BYTE xdata *)addr+i);
				IN0BC = (BYTE)bc;       // Arm endpoint
				addr += bc;
				len -= bc;
				while(EP0CS & 0x04);    // Wait for INBSY to clear
			}
            IN0BC = 0x00;             // arm endp, # bytes to xfr
            EP0CS |= bmBIT1;          // ack handshake phase of device request
		}
        break;
    }


    default:
    {
      break;
    }
  }
  return( FALSE );              // no errors, cmd handled okay
}

//-----------------------------------------------------------------------------
// USB Interrupt Handlers
//	The following functions are called by the USB interrupt jump table.
//-----------------------------------------------------------------------------

// Setup Data Available Interrupt Handler
void ISR_Sudav(void) interrupt 0
{
	GotSUD = TRUE;				// Set flag
	EZUSB_IRQ_CLEAR();
	USBIRQ = bmSUDAV;			// Clear SUDAV IRQ
}

// Setup Token Interrupt Handler
void ISR_Sutok(void) interrupt 0
{
	EZUSB_IRQ_CLEAR();
	USBIRQ = bmSUTOK;			// Clear SUTOK IRQ
}

void ISR_Sof(void) interrupt 0
{
	EZUSB_IRQ_CLEAR();
	USBIRQ = bmSOF;				// Clear SOF IRQ
}

void ISR_Ures(void) interrupt 0
{
	EZUSB_IRQ_CLEAR();
	USBIRQ = bmURES;			// Clear URES IRQ
}

void ISR_IBN(void) interrupt 0
{
}

void ISR_Susp(void) interrupt 0
{
	Sleep = TRUE;
	EZUSB_IRQ_CLEAR();
	USBIRQ = bmSUSP;
}

void ISR_Ep0in(void) interrupt 0
{
}

void ISR_Ep0out(void) interrupt 0
{
}

void ISR_Ep1in(void) interrupt 0
{
}

void ISR_Ep1out(void) interrupt 0
{
	int i;

	for(i=0;i<OUT1BC;i++)
		HOSTCMD[i] = OUT1BUF[i];

	OUT1BC = 0;
	BULK_OUT_DONE = TRUE;
 	EZUSB_IRQ_CLEAR();
   	OUT07IRQ = bmEP1;
}

void ISR_Ep2in(void) interrupt 0
{
}

void ISR_Ep2out(void) interrupt 0
{
}

void ISR_Ep3in(void) interrupt 0
{
}

void ISR_Ep3out(void) interrupt 0
{
}

void ISR_Ep4in(void) interrupt 0
{
}

void ISR_Ep4out(void) interrupt 0
{
}

void ISR_Ep5in(void) interrupt 0
{
}

void ISR_Ep5out(void) interrupt 0
{
}

void ISR_Ep6in(void) interrupt 0
{
}

void ISR_Ep6out(void) interrupt 0
{
}

void ISR_Ep7in(void) interrupt 0
{
}

void ISR_Ep7out(void) interrupt 0
{
}
