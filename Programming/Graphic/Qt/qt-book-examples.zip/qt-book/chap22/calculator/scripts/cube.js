return x * x * x;
