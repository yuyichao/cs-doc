/*1:*/
#line 16 "gbkfonts.w"

/*2:*/
#line 22 "gbkfonts.w"

#include <stdio.h> 
#include <process.h> 
#include <string.h> 
#include <direct.h> 
#include <stdarg.h> 
#include <windows.h> 
#include <winbase.h> 
#include <signal.h> 

/*:2*/
#line 17 "gbkfonts.w"

/*3:*/
#line 32 "gbkfonts.w"

static char gb[128],gbk[128],compact[128];
static char gbkface[128],slface[128];
static char name[128],slname[128];
static char ttf_file[128],ttf_basename[128],fontname[128];
static char cmd[128],cmd1[128],plane[8];
static int bt,bc,bgbk,bv,bf;


/*:3*/
#line 18 "gbkfonts.w"

/*4:*/
#line 42 "gbkfonts.w"

void fatal(char*str)
{
fprintf(stderr,str);
exit(-1);
}

void show(char*str)
{
if(bv){
fprintf(stderr,str);
fprintf(stderr,"\n");
}
}

/*:4*//*10:*/
#line 140 "gbkfonts.w"

char*trimpath(char*str)
{

char*ptr;
ptr= strrchr(str,'\\');
if(ptr==0)ptr= strrchr(str,'/');
if(ptr==0)return str;else return ptr+1;
}

/*:10*//*14:*/
#line 201 "gbkfonts.w"

void showhelp()
{
puts("Usage:   gbkfonts [-c] [-v] [-f] [-t] [-gbk] ttf_file gbkface");
puts("\t      -c: create CJK compact font");
puts("\t      -v: verbose, show the commands");
puts("\t      -f: only create config and map files");
puts("\t      -t: create traditional font");
puts("\t    -gbk: add this if your ttf is GBK font");
puts("\tttf_file: TTF file name");
puts(" gbkface: song/hei/kai/li/fs, etc. see gbkfonts.ini");
puts("");
puts("Make pfb, afm, tfm and enc files from ttf_file,");
puts("also make all map files needed.");
puts("The font definitions are in gbkfonts.ini.");
puts("");
puts("Example: gbkfonts -c -gbk c:\\windows\\fonts\\simsun.ttf song");
puts("");
puts("Then copy folder \"dvips\", \"tex\", \"dvipdfm\", \
and \"fonts\" to TEXMF-LOCAL,");
puts("append file cjk.map to c:\\TeX\\texmf\\dvips\\base\\cjk.map,");
puts("append file cid-x.map to c:\\TeX\\texmf\\dvipdfm\\config\\\
cid-x.map,");
}

/*:14*//*27:*/
#line 445 "gbkfonts.w"

void sig_int(int sig)
{
_unlink("cjk.Fontmap");
fprintf(stderr,"\n\n! Interrupted by user\n");
exit(2);
}
/*:27*/
#line 19 "gbkfonts.w"

/*15:*/
#line 226 "gbkfonts.w"

int main(int argc,char*argv[])
{
/*5:*/
#line 58 "gbkfonts.w"

FILE*fin;
char buf[128],*ptr;

/*:5*//*11:*/
#line 150 "gbkfonts.w"

int i,eid,fontuid,n,nn,total_char,offset;
FILE*pfbmapfile,*ttfmapfile,*fout,*dvipdfm_mapfile,*fd_file;
char s_face[128];

/*:11*/
#line 229 "gbkfonts.w"
;
/*26:*/
#line 442 "gbkfonts.w"

signal(SIGINT,sig_int);

/*:26*/
#line 230 "gbkfonts.w"
;
/*16:*/
#line 262 "gbkfonts.w"

strcpy(gb,"gb");
strcpy(gbk,"");
strcpy(compact,"");
strcpy(ttf_file,"");
strcpy(gbkface,"");


/*:16*/
#line 231 "gbkfonts.w"
;
/*17:*/
#line 270 "gbkfonts.w"

if(argc<2||argc> 6)
{
showhelp();
return-1;
}

for(i= 1;i<argc;i++)
{
if(strcmp(argv[i],"-c")==0){
strcpy(compact,"-c");
bc= 1;
}else if(strcmp(argv[i],"-gbk")==0){
strcpy(gbk,"-gbk");
bgbk= 1;
strcpy(gb,"gbk");
}else if(strcmp(argv[i],"-t")==0){
strcpy(gb,"gt");
bt= 1;
}else if(strcmp(argv[i],"-v")==0)bv= 1;
else if(strcmp(argv[i],"-f")==0)bf= 1;
else if(ttf_file[0]==0)strcpy(ttf_file,argv[i]);
else if(gbkface[0]==0)strcpy(gbkface,argv[i]);
else{
showhelp();
return-1;
}
}
fprintf(stderr,"%s\n",ttf_file);
if(_access(ttf_file,0)==-1)
fatal("Can't open font file");
strcpy(ttf_basename,trimpath(ttf_file));

/*:17*/
#line 232 "gbkfonts.w"
;
/*7:*/
#line 63 "gbkfonts.w"

sprintf(buf,"ftdump %s",ttf_file);
if((fin= _popen(buf,"r"))==NULL)
fatal("can't find ftpdump program\n");

while(!feof(fin))
{
if(fgets(buf,128,fin)==0)
fatal("Error: file encoding not supported.");

if(ptr= strstr(buf,"Windows Unicode")){
eid= 1;break;
}

if(ptr= strstr(buf,"Windows GB2312")){
eid= 3;break;
}
}

fclose(fin);

/*:7*/
#line 233 "gbkfonts.w"
;
/*8:*/
#line 87 "gbkfonts.w"

if((fin= fopen("gbkfonts.ini","rt"))==NULL)
fatal("can't open gbkfonts.ini\n");

while(!feof(fin))
{
n= fscanf(fin,"%s %s %s %d",s_face,slface,fontname,&fontuid);
if(n!=4)continue;
if(strcmp(gbkface,s_face)==0)break;
fontuid= 0;
}
fclose(fin);

if(fontuid==0)fatal("Can find font UID in gbkfonts.ini");

/*:8*/
#line 234 "gbkfonts.w"
;
/*19:*/
#line 338 "gbkfonts.w"

if(bc&&bgbk)total_char= 94;
else if(bc&&!bgbk)total_char= 35;
else if(!bc&&bgbk)total_char= 126;
else total_char= 81;

/*:19*/
#line 236 "gbkfonts.w"
;
/*18:*/
#line 303 "gbkfonts.w"

_mkdir("fonts");
_mkdir("fonts/afm");
_mkdir("fonts/tfm");
_mkdir("fonts/type1");
_mkdir("fonts/afm/chinese");
_mkdir("fonts/tfm/chinese");
_mkdir("fonts/type1/chinese");

_mkdir("dvips");
_mkdir("dvips/chinese");

_mkdir("pdftex");
_mkdir("pdftex/config");

_mkdir("dvipdfm");
_mkdir("dvipdfm/config");

_mkdir("tex");
_mkdir("tex/latex");
_mkdir("tex/latex/CJK");
_mkdir("tex/latex/CJK/GB");

sprintf(cmd,"dvips/chinese/%s%s",gb,gbkface);
_mkdir(cmd);

sprintf(cmd,"fonts/afm/chinese/%s%s",gb,gbkface);
_mkdir(cmd);

sprintf(cmd,"fonts/tfm/chinese/%s%s",gb,gbkface);
_mkdir(cmd);

sprintf(cmd,"fonts/type1/chinese/%s%s",gb,gbkface);
_mkdir(cmd);

/*:18*/
#line 237 "gbkfonts.w"
;
/*20:*/
#line 344 "gbkfonts.w"

pfbmapfile= fopen("cjk.map","at");
sprintf(cmd,"pdftex/config/%s%s.map",gb,gbkface);
ttfmapfile= fopen(cmd,"wt");
sprintf(cmd,"dvipdfm/config/%s%s.map",gb,gbkface);
dvipdfm_mapfile= fopen(cmd,"wt");

/*:20*/
#line 238 "gbkfonts.w"
;




fprintf(stderr,"Processing %s%s\n",gb,gbkface);

for(n= 1;n<=total_char;n++){

fprintf(stderr,"[%d]",n);
/*21:*/
#line 351 "gbkfonts.w"

if(bc)offset= 0;
else if(bgbk)offset= 0x80;
else if(n<=9)offset= 0xa0;
else offset= 0xa6;
nn= n+offset;

/*:21*/
#line 248 "gbkfonts.w"
;
/*12:*/
#line 160 "gbkfonts.w"

if(bc)
sprintf(plane,"%02d",nn);
else
sprintf(plane,"%02x",nn);

sprintf(name,"%s%s%s",gb,gbkface,plane);
sprintf(slname,"%s%s%s",gb,slface,plane);

/*:12*/
#line 249 "gbkfonts.w"
;

if(bf)goto skipfontmake;
/*22:*/
#line 358 "gbkfonts.w"


sprintf(cmd,"ttf2pfb -a -pid 3 -eid %d %s -force UGBK \
	-plane %d %s -uid %d -f %s %s -o %s.ps",
eid,gbk,nn,compact,fontuid,fontname,ttf_file,name);
show(cmd);
system(cmd);


sprintf(cmd,"t1asm -b %s.ps > %s.pfb",name,name);
show(cmd);
system(cmd);


sprintf(cmd,"%s.ps",name);
_unlink(cmd);


sprintf(cmd,"type1afm %s.pfb",name);
system(cmd);


fout= fopen("cjk.Fontmap","a");
fprintf(fout,"/%s%s (%s.pfb) ;\n",fontname,plane,name);
fclose(fout);


sprintf(cmd,"afm2tfm %s.afm",name);
show(cmd);
system(cmd);


sprintf(cmd,"afm2tfm %s.afm -s .167 %s.tfm",name,slname);
show(cmd);
system(cmd);


/*:22*/
#line 252 "gbkfonts.w"
;
/*23:*/
#line 395 "gbkfonts.w"


sprintf(cmd,"%s.afm",name);
sprintf(cmd1,"fonts/afm/chinese/%s%s/%s.afm",gb,gbkface,name);
MoveFileEx(cmd,cmd1,MOVEFILE_REPLACE_EXISTING);


sprintf(cmd,"%s.tfm",name);
sprintf(cmd1,"fonts/tfm/chinese/%s%s/%s.tfm",gb,gbkface,name);
MoveFileEx(cmd,cmd1,MOVEFILE_REPLACE_EXISTING);


sprintf(cmd,"%s.tfm",slname);
sprintf(cmd1,"fonts/tfm/chinese/%s%s/%s.tfm",gb,gbkface,slname);
MoveFileEx(cmd,cmd1,MOVEFILE_REPLACE_EXISTING);


sprintf(cmd,"%s.pfb",name);
sprintf(cmd1,"fonts/type1/chinese/%s%s/%s.pfb",gb,gbkface,name);
MoveFileEx(cmd,cmd1,MOVEFILE_REPLACE_EXISTING);


sprintf(cmd,"%s.enc",name);
sprintf(cmd1,"dvips/chinese/%s%s/%s.enc",gb,gbkface,name);
MoveFileEx(cmd,cmd1,MOVEFILE_REPLACE_EXISTING);

/*:23*/
#line 253 "gbkfonts.w"
;
skipfontmake:
/*24:*/
#line 421 "gbkfonts.w"


fprintf(ttfmapfile,"%s <%s.enc <%s\n",name,name,ttf_basename);

fprintf(ttfmapfile,"%s <%s.enc <%s\n",slname,name,ttf_basename);
fprintf(dvipdfm_mapfile,"%s none %s\n",name,name);

fprintf(dvipdfm_mapfile,"%s none %s -s .167\n",slname,name);


fprintf(pfbmapfile,"%s %s%s <%s.pfb\n",name,fontname,plane,name);

fprintf(pfbmapfile,"%s %s%s \" .167 SlantFont \" < %s.pfb\n",
slname,fontname,plane,name);

/*:24*/
#line 255 "gbkfonts.w"
;
}
/*25:*/
#line 436 "gbkfonts.w"

fclose(ttfmapfile);
fclose(pfbmapfile);
fclose(dvipdfm_mapfile);
_unlink("cjk.Fontmap");

/*:25*/
#line 257 "gbkfonts.w"
;
/*13:*/
#line 179 "gbkfonts.w"


fout= fopen("cid-x.map","a");
fprintf(fout,"gb%s@UGBK@             UniGB-UCS2-H    :0:%s\n",gbkface,ttf_basename);

fprintf(fout,"gb%ssl@UGBK@             UniGB-UCS2-H    :0:%s\n",gbkface,ttf_basename);
fclose(fout);


fout= fopen("pdftex.cfg","a");
fprintf(fout,"map +%s%s.map\n",gb,gbkface);
fclose(fout);


fout= fopen("ttfonts.map","a");
fprintf(fout,"%s%s@UGBK@    %s  Pid = 3 Eid = %d\n",gb,gbkface,ttf_basename,eid);
fprintf(fout,"%s%s@UGBK@    %s  Slant = 0.167 Pid = 3 Eid = %d\n",
gb,slface,ttf_basename,eid);
fclose(fout);

/*9:*/
#line 106 "gbkfonts.w"


sprintf(cmd,"tex/latex/CJK/GB/c19%s.fd",gbkface);
fd_file= fopen(cmd,"wt");
fprintf(fd_file,"%% This is the file c19%s.fd of the CJK package\n",gbkface);
fprintf(fd_file,"%% for using Asian logographs (Chinese/Japanese/Korean) with LaTeX2e\n");
fprintf(fd_file,"%% created by Werner Lemberg <wl@gnu.org>\n");
fprintf(fd_file,"%% Version 4.3.0 (20-Jun-1999)\n\n");
fprintf(fd_file,"\\def\\fileversion{4.3.0}\n");
fprintf(fd_file,"\\def\\filedate{1999/06/20}\n\n");
fprintf(fd_file,"%% \\ProvidesFile{c19%s.fd}[\\filedate\\space\\fileversion]\n",gbkface);
fprintf(fd_file,"%% Chinese characters (extension of GB 2312)\n");
fprintf(fd_file,"%% character set: GBK\n");
fprintf(fd_file,"%% font encoding: CJK (extended)\n\n");
fprintf(fd_file,"\\DeclareFontFamily{C19}{%s}{}\n",gbkface);
fprintf(fd_file,"\\DeclareFontShape{C19}{%s}{m}{n}{<-> CJK * %s%s}{}\n",gbkface,gb,gbkface);
fprintf(fd_file,"\\DeclareFontShape{C19}{%s}{bx}{n}{<-> CJKb * %s%s}{}\n",gbkface,gb,gbkface);
fprintf(fd_file,
"\\DeclareFontShape{C19}{%s}{m}{it}{<-> CJK * %s%ssl}{}\n",
gbkface,gb,gbkface);
fprintf(fd_file,
"\\DeclareFontShape{C19}{%s}{bx}{it}{<-> CJKb * %s%ssl}{}\n",
gbkface,gb,gbkface);
fprintf(fd_file,
"\\DeclareFontShape{C19}{%s}{m}{sl}{<-> CJK * %s%ssl}{}\n",
gbkface,gb,gbkface);
fprintf(fd_file,
"\\DeclareFontShape{C19}{%s}{bx}{sl}{<-> CJKb * %s%ssl}{}\n",
gbkface,gb,gbkface);
fprintf(fd_file,"\n\\endinput\n");
fclose(fd_file);


/*:9*/
#line 199 "gbkfonts.w"


/*:13*/
#line 258 "gbkfonts.w"
;
return 0;
}

/*:15*/
#line 20 "gbkfonts.w"


/*:1*/
