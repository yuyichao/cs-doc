This directory contains demo code that implement an embedded host using the SL811HST.
Note: The code size exceeds the Keil Demo compiler limit of 4K bytes, so the full 
Keil tools must be used to build this example.
