//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by EZ811_DK.rc
//
#define IDC_ABOUT                       1000
#define IDC_DRIVER_NAME                 1004
#define IDC_CLEAR                       1024
#define IDC_START_STOP                  1025
#define IDC_SNGL_XFER                   1026
#define IDC_RESET_EZ811                 1030
#define IDC_FILE_XFER                   1031
#define IDC_SAVE_OUTPUT                 1032
#define IDC_USB_ADDRESS                 1062
#define IDC_ENDPOINT_ADDR               1064
#define IDC_DATA_SIZE                   1065
#define IDC_DEV_DESCP                   1069
#define IDC_QUIT                        1070
#define IDC_STR_DESCP                   1071
#define IDC_SHOW_REGS                   1072
#define IDC_CFG_DESCP                   1073
#define IDC_CLASS_DESCP                 1074
#define IDC_DATA_BOX                    1088
#define IDC_INFO_BOX                    1089
#define IDC_STATUS_BOX                  1090
#define IDC_IN                          1094
#define IDC_OUT                         1095
#define IDC_INT_XFER                    1096
#define IDC_BULK_XFER                   1097
#define IDC_ISO_XFER                    1098
#define IDC_REPEAT                      1102
#define IDC_UPDATE_DEVS_AUTO            1107
#define IDC_REPEAT_PEND                 1108
#define IDC_REFRESH                     1109
#define IDC_FILE_OUT                    1111
#define IDC_SAVE_OUT_FILE               1112

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        124
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1112
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
