/*
  Project:       AVR �๦��ʵ��� uSTKm �������2
                 ����AVR��Ƭ�����ڲ���׼����VCC��ѹ

  File:          demo.c

  Version:       1.0

  Compile:       WinAVR 20071221

  Author:        Shaoziyang
                 Shaoziyang@gmail.com
                 http://avrubd.googlepages.com

  Date:          2008.Mar

*/

#include "bootcfg.h"
#include "bootldr.h"

//ʵ���ڲ��ο���׼1.05V
#define VREF 105UL

unsigned char dat = '1';
unsigned int vcc = 0;
unsigned char msg[20];

//д�����ݵ�����
void WriteCom(unsigned char dat)
{
#if RS485
  RS485Enable();
#endif

  UDRREG(COMPORTNo) = dat;
  while(!(UCSRAREG(COMPORTNo) & (1<<TXCBIT(COMPORTNo))));
  UCSRAREG(COMPORTNo) |= (1 << TXCBIT(COMPORTNo));

#if RS485
  RS485Disable();
#endif
}

void putstr(const char *str)
{
  while(*str)
    WriteCom(*str++);
  WriteCom(0x0D);
  WriteCom(0x0A);
}

unsigned int ad(unsigned char chn)
{
  ADMUX = (0 << REFS1)|(1 << REFS0)| (chn % 16);
  ADCSRA = (1 << ADEN)|(1 << ADSC)|(1 << ADPS2)|(1 << ADPS1);
  while(ADCSRA & (1 << ADSC));
  return ADC;
}

int main(void)
{
  asm volatile("cli": : );

#if WDGEn
  //�������Ź�
  wdt_enable(WDTO_1S);
#endif

  ComInit();
  TimerInit();

#if RS485
  DDRREG(RS485PORT) |= (1 << RS485TXEn);
  RS485Disable();
#endif

#if LEDEn
  //����LED�˿�Ϊ���״̬
  DDRREG(LEDPORT) = (1 << LEDPORTNo);
#endif

  while(1)
  {
#if WDGEn
    //������Ź�
    wdt_reset();
#endif

    if(TIFRREG & (1<<OCF1A))    //T1���
    {
      TIFRREG |= (1 << OCF1A);

#if LEDEn
      //LED����״̬
      LEDAlt();
#endif

      if(DataInCom())
      {
        if(ReadCom() == '~')
          while(1);             //��ѭ�����ȴ���λ
      }

      vcc = ad(0x0E);
	  if(vcc > 0)
	    vcc = VREF * 1024 / vcc;//����ɵ�ѹ
      else
        vcc = 9999;//error!

      WriteCom('>');
      WriteCom((vcc / 1000) + '0');
      vcc = vcc % 1000;
      WriteCom((vcc / 100) + '0');
      vcc = vcc % 100;
	  WriteCom('.');
      WriteCom((vcc / 10) + '0');
      WriteCom((vcc % 10) + '0');
	  putstr(" V");
    }
  }

  return 0;
}
